# semi-SFAug
Semi segmentation of Thyroid nodules. The code will be released soon.
