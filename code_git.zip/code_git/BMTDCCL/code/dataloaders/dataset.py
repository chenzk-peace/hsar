import itertools
import os
import random
import re
from glob import glob
import sys
import cv2
import h5py
import numpy as np
import torch
from scipy import ndimage
from scipy.ndimage.interpolation import zoom
from torch.utils.data import Dataset
from torch.utils.data.sampler import Sampler
from PIL import Image
from PIL import ImageFilter

class BaseDataSets(Dataset):
    def __init__(self, base_dir=None, split='train', num=None, transform=None):
        self._base_dir = base_dir
        self.sample_list = []
        self.split = split
        self.transform = transform
        self.sep = '\\' if sys.platform[:3] == 'win' else '/'

        if self.split == "train":
            self.image_files = sorted([os.path.join(base_dir, x, y, z)
                                       for x in os.listdir(base_dir) if x.endswith('TrainDataset')
                                       for y in os.listdir(os.path.join(base_dir, x)) if y.endswith('images')
                                       for z in os.listdir(os.path.join(base_dir, x, y))])
            self.label_files = sorted([os.path.join(base_dir, x, y, z)
                                       for x in os.listdir(base_dir) if x.endswith('TrainDataset')
                                       for y in os.listdir(os.path.join(base_dir, x)) if y.endswith('masks')
                                       for z in os.listdir(os.path.join(base_dir, x, y))])
            self.image_files = sorted(list(set(self.image_files) - set(self.image_files[::5])))
            self.label_files = sorted(list(set(self.label_files) - set(self.label_files[::5])))
            self.sample_list = self.image_files
            print("Train total {} samples".format(len(self.sample_list)))
        elif self.split == "val":
            self.image_files = sorted([os.path.join(base_dir, x, y, z)
                                       for x in os.listdir(base_dir) if x.endswith('TrainDataset')
                                       for y in os.listdir(os.path.join(base_dir, x)) if y.endswith('images')
                                       for z in os.listdir(os.path.join(base_dir, x, y))])
            self.label_files = sorted([os.path.join(base_dir, x, y, z)
                                       for x in os.listdir(base_dir) if x.endswith('TrainDataset')
                                       for y in os.listdir(os.path.join(base_dir, x)) if y.endswith('masks')
                                       for z in os.listdir(os.path.join(base_dir, x, y))])
            self.image_files = sorted(self.image_files[::5])
            self.label_files = sorted(self.label_files[::5])
            self.sample_list = self.image_files
            print("val total {} samples".format(len(self.sample_list)))
        elif self.split == "test":
            self.image_files = sorted([os.path.join(base_dir, x, y, z)
                                       for x in os.listdir(base_dir) if x.endswith('TestDataset')
                                       for y in os.listdir(os.path.join(base_dir, x)) if y.endswith('images')
                                       for z in os.listdir(os.path.join(base_dir, x, y))])
            self.label_files = sorted([os.path.join(base_dir, x, y, z)
                                       for x in os.listdir(base_dir) if x.endswith('TestDataset')
                                       for y in os.listdir(os.path.join(base_dir, x)) if y.endswith('masks')
                                       for z in os.listdir(os.path.join(base_dir, x, y))])
            assert len(self.image_files) == len(self.label_files)
            self.sample_list = self.image_files
            print("Val total {} samples".format(len(self.sample_list)))
        if num is not None and self.split == "train":
            self.sample_list = self.sample_list[:num]

    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):
        case = self.sample_list[idx]
        if self.split == "train":
            assert self.image_files[idx].split(self.sep)[-1][:-4] == self.label_files[idx].split(self.sep)[-1][:-4]
            img, mask = self.image_files[idx], self.label_files[idx]  # [224,224] [224,224]
            img = Image.open(img)  # 因为isic加了convert
            mask = Image.open(mask)
            # img = img.convert('L')
            # mask = mask.convert('L')
            img = img.resize((256, 256), Image.LANCZOS)
            mask = mask.resize((256, 256), Image.NEAREST)
            image = np.array(img)
            # mask = np.array(mask,dtype=bool)
            # mask = mask.astype('uint8')
            mask = np.array(mask).astype('uint8')
            label = np.where(mask > 128, 1, 0)
            # label = torch.from_numpy(np.array(label)).unsqueeze(0)
        elif self.split == "val" or self.split == "test":
            assert self.image_files[idx].split(self.sep)[-1][:-4] == self.label_files[idx].split(self.sep)[-1][:-4]
            # image = io.imread(self.image_files[idx]).astype('uint8')
            # # image = numpy.array(image)
            # # image = Image.fromarray(image).convert('RGB').resize((512, 512))
            # label = io.imread(self.label_files[idx]).astype('bool').astype('uint8')
            img = self.image_files[idx]
            mask = self.label_files[idx]
            img = Image.open(img)  # 同理
            mask = Image.open(mask)
            # img = img.convert('L')
            # mask = mask.convert('L')
            img = img.resize((256, 256), Image.LANCZOS)
            mask = mask.resize((256, 256), Image.NEAREST)
            image = np.array(img)
            # mask = np.array(mask,dtype=bool)
            # mask = mask.astype('uint8')
            mask = np.array(mask).astype('uint8')
            label = np.where(mask > 128, 1, 0)
        sample = {'image': image, 'label': label}
        if self.split == "train":
            sample = self.transform(sample)
        sample["idx"] = idx
        return sample


def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    label = np.flip(label, axis=axis).copy()
    return image, label


def random_rotate(image, label, cval):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0,
                           reshape=False, mode="constant", cval=cval)
    return image, label


class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']
        # ind = random.randrange(0, img.shape[0])
        # image = img[ind, ...]
        # label = lab[ind, ...]
        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            if 4 in np.unique(label):
                image, label = random_rotate(image, label, cval=4)
            else:
                image, label = random_rotate(image, label, cval=0)
        x, y = image.shape
        image = zoom(
            image, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        label = zoom(
            label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        image = torch.from_numpy(
            image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.uint8))
        sample = {'image': image, 'label': label}
        return sample


class TwoStreamBatchSampler(Sampler):
    """Iterate two sets of indices

    An 'epoch' is one iteration through the primary indices.
    During the epoch, the secondary indices are iterated through
    as many times as needed.
    """

    def __init__(self, primary_indices, secondary_indices, batch_size, secondary_batch_size):
        self.primary_indices = primary_indices
        self.secondary_indices = secondary_indices
        self.secondary_batch_size = secondary_batch_size
        self.primary_batch_size = batch_size - secondary_batch_size

        assert len(self.primary_indices) >= self.primary_batch_size > 0
        assert len(self.secondary_indices) >= self.secondary_batch_size > 0

    def __iter__(self):
        primary_iter = iterate_once(self.primary_indices)
        secondary_iter = iterate_eternally(self.secondary_indices)
        return (
            primary_batch + secondary_batch
            for (primary_batch, secondary_batch)
            in zip(grouper(primary_iter, self.primary_batch_size),
                   grouper(secondary_iter, self.secondary_batch_size))
        )

    def __len__(self):
        return len(self.primary_indices) // self.primary_batch_size


def iterate_once(iterable):
    return np.random.permutation(iterable)


def iterate_eternally(indices):
    def infinite_shuffles():
        while True:
            yield np.random.permutation(indices)
    return itertools.chain.from_iterable(infinite_shuffles())


def grouper(iterable, n):
    "Collect data into fixed-length chunks or blocks"
    # grouper('ABCDEFG', 3) --> ABC DEF"
    args = [iter(iterable)] * n
    return zip(*args)
