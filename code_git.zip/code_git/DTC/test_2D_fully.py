import argparse
import os
import shutil

import h5py
import nibabel as nib
import numpy as np
import SimpleITK as sitk
import torch
from medpy import metric
from scipy.ndimage import zoom
from scipy.ndimage.interpolation import zoom
from tqdm import tqdm
from PIL import Image
# from networks.efficientunet import UNet
from SSL4MIS_master.code.networks.net_factory import net_factory
import cv2
parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default='/media/pc/180A0B207684C9D9/czkdata/Czk_data/Thyroid Dataset all', help='Name of Experiment')
parser.add_argument('--exp', type=str,
                    default='Thy0.05/Deep_Co_Training', help='experiment_name')
parser.add_argument('--model', type=str,
                    default='unet', help='model_name')
parser.add_argument('--num_classes', type=int,  default=2,
                    help='output channel of network')
parser.add_argument('--labeled_num', type=float, default=0.05,
                    help='labeled data')
args = parser.parse_args()

def plot_mask(img, masks, colors=None, alpha=0.5) -> np.ndarray:
    """Visualize segmentation mask.

     Parameters
     ----------
     img: numpy.ndarray
         Image with shape `(H, W, 3)`.
     masks: numpy.ndarray
         Binary images with shape `(N, H, W)`.
     colors: numpy.ndarray
         color for mask, shape `(N, 3)`.
         if None, generate random color for mask
     alpha: float, optional, default 0.5
         Transparency of plotted mask

     Returns
     -------
     numpy.ndarray
         The image plotted with segmentation masks, shape `(H, W, 3)`

     """
    if colors is None:
        colors = np.random.random((masks.shape[0], 3)) * 255
    else:
        if colors.shape[0] < masks.shape[0]:
            raise RuntimeError(
                f"colors count: {colors.shape[0]} is less than masks count: {masks.shape[0]}"
            )
    for mask, color in zip(masks, colors):
        mask = np.stack([mask, mask, mask], -1)
        img = np.where(mask, img * (1 - alpha) + color * alpha, img)

    return img.astype(np.uint8)
def read_image_color(image_path, label_path, color_map):
    """
    :param image_path: 图像文件路径
    :param label_path: 标签文件路径
    :param color_map: 输入的颜色列表
    :returns:
    img: numpy.ndarray
         Image with shape `(H, W, 3)`.
     label_trans: numpy.ndarray
         Binary images with shape `(N, H, W)`.
     RGB_map: numpy.ndarray
         color for mask, shape `(N, 3)`.
    """

    if image_path.min() < 0:
        image_path = (image_path + 1) * 127.5
    elif image_path.max() < 1:
        image_path = image_path * 255

    img = image_path
    mask = label_path
    mask = mask[:, :, np.newaxis]
    # print(mask.shape)
    label_trans = mask.transpose(2, 0, 1)
    color_map[0], color_map[2] = color_map[2], color_map[0]
    RGB_map = np.array(color_map)
    RGB_map = RGB_map.T
    RGB_map = RGB_map[np.newaxis, :]
    # print(color_RGB.shape)
    return img, label_trans, RGB_map
def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    dice = metric.binary.dc(pred, gt)
    if pred.sum() > 1e-4:
        asd = metric.binary.asd(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
    else:
        asd = 100
        hd95 = 100
    return dice, hd95, asd


def test_single_volume(case, net, test_save_path, FLAGS,lens,idx,modelname):
    test_save_path = "/home/pc/Czk/SSL4MIS_master/model/img/DCT/thy_{}_{}_labeled/img256{}/".format(
        FLAGS.exp,
        FLAGS.labeled_num, modelname)
    if not os.path.exists(test_save_path):
        os.makedirs(test_save_path)

    path = FLAGS.root_path + '/TestDataset/images/{}'.format(case)
    path2 = FLAGS.root_path + '/TestDataset/masks/{}'.format(case)

    img = Image.open(path).convert('L')
    mask = Image.open(path2).convert('L')
    img = img.resize((256, 256), Image.LANCZOS)
    mask = mask.resize((256, 256), Image.NEAREST)
    image = np.array(img)[np.newaxis, :]

    label = np.array(mask).astype('uint8')[np.newaxis, :]
    # a = cv2.imread(path,cv2.COLOR_GRAY2RGB)
    # b = cv2.imread(path2,cv2.IMREAD_GRAYSCALE)
    # image = cv2.imread(path,cv2.COLOR_GRAY2RGB)[np.newaxis, :]
    # label = cv2.imread(path2,cv2.IMREAD_GRAYSCALE)[np.newaxis, :]
    label = np.where(label > 128, 1, 0)
    prediction = np.zeros_like(label)
    for ind in range(image.shape[0]):
        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (256 / x, 256 / y), order=0)
        input = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().cuda()
        net.eval()
        with torch.no_grad():
            if FLAGS.model == "unet_urds":
                out_main, _, _, _ = net(input)
            else:
                out_main = net(input)['out']
            out = torch.argmax(torch.softmax(
                out_main, dim=1), dim=1).squeeze(0)
            out = out.cpu().detach().numpy()
            pred = zoom(out, (x / 256, y / 256), order=0)
            prediction[ind] = pred

    img = Image.open(path)  # isic是三通道的
    img = img.resize((256, 256), Image.LANCZOS)
    first_metric = calculate_metric_percase(prediction == 1, label == 1)

    H1, W1 = 256, 256
    img = img.convert('RGB')
    image = np.array(img).astype('uint8')

    label = label.squeeze(0)
    prediction = prediction.squeeze(0)
    mask_color = [
        0, 0, 255
    ]  # 输入颜色数组为RGB格p式,这里只支持单类别的颜色设置，多类别的后续可能会改进出来
    mask_color_2 = [255, 0, 0]
    # label2[label2!=255]=255
    # _, label2 = cv2.threshold(label, 128, 255, cv2.THRESH_BINARY) #去除边缘噪声!!很关键
    image, label2, color_RGB = read_image_color(image, label, mask_color)
    label2 = plot_mask(image, label2, colors=color_RGB, alpha=0.5)
    label2, pred, color_RGB_2 = read_image_color(label2, prediction, mask_color_2)
    pred = plot_mask(label2, pred, colors=color_RGB_2, alpha=0.5)
    cv2.imwrite(test_save_path + case[:-4] + '_img.png', image)
    cv2.imwrite(test_save_path + case[:-4] + '_lbl.png',
                label2)
    cv2.imwrite(test_save_path + case[:-4] + '_prd.png',
                pred)
    print('itr/itrs: {}/{}'.format(idx, len(lens)))
    return first_metric

path = args.root_path + '/TestDataset/test-images/'
def Inference(FLAGS):
    image_list = sorted([x for x in os.listdir(path)])
    # image_list = sorted([item.replace('\n', '').split(".")[0]for item in image_list])
    # snapshot_path = "/home/pc/Czk/ssseg/ABD_main/model/BCPrun/ACDC_{}_{}_labeled".format(FLAGS.exp, FLAGS.labeled_num)
    # test_save_path = "/home/pc/Czk/ssseg/ABD_main/model/BCPrun/ACDC_{}_{}_labeled/{}_predictions_model/".format(FLAGS.exp, FLAGS.labeled_num, FLAGS.model_1)
    snapshot_path = "/home/pc/Czk/SSL4MIS_master/model/{}_{}_labeled/{}".format(FLAGS.exp,
                                                                                                    FLAGS.labeled_num,FLAGS.model)
    test_save_path = "/home/pc/Czk/SSL4MIS_master/model/1{}_{}_labeled/{}/".format(
        FLAGS.exp,
        FLAGS.labeled_num,
        FLAGS.model)
    if not os.path.exists(test_save_path):
        os.makedirs(test_save_path)
    net = net_factory(net_type=FLAGS.model, in_chns=1,
                      class_num=FLAGS.num_classes)
    save_mode_path = os.path.join(
        snapshot_path, '{}_best_model.pth'.format(FLAGS.model))
    net.load_state_dict(torch.load(save_mode_path))
    print("init weight from {}".format(save_mode_path))
    net.eval()

    first_total = 0.0
    i = 1
    for case in tqdm(image_list):
        first_metric = test_single_volume(case, net, test_save_path, FLAGS, image_list, i, FLAGS.model_1 + '1')
        first_total += np.asarray(first_metric)
        i += 1

    avg_metric = [first_total / len(image_list)]
    average = avg_metric[0]
    print(avg_metric)
    print(f'average:{average}')
    with open(os.path.join(test_save_path, 'performance.txt'), 'w') as file:
        file.write(str(avg_metric) + '\n')
        file.write(str(average) + '\n')
    return avg_metric


if __name__ == '__main__':
    FLAGS = parser.parse_args()
    metric = Inference(FLAGS)

