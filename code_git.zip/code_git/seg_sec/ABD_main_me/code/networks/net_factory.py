from .unet import UNet, UNet_2d
# from ACMT.code.networks.unet import UNetacmt
# import torch.nn as nn
# from seg_sec.ABD_main_me.models import deeplabv3
from seg_sec.ABD_main_me.utils.model_init import init_weight
# # from BMTDCCL.code.networks.unet import *
from ALHVR.train_ALHVR.code.networks.unet import UNet_fea_aux
from seg_sec.ABD_main_me.deeplab.deeplabv3_plus import Deeplabv3plus
# # # from SSL4MIS_master.code.networks.unet import UNet, UNet_DS, UNet_URPC, UNet_CCT
# from SSL4MIS_master.code.networks.unet import UNet_DTC
# # # from SSL4MIS_master.code.networks.ssnet import SSNet
# from PCL.networks.unet import SAMT_PCL
# from CML.CMLmain.code.networks import unet
# from DCNet.code.networks.unet import *
from CGS.networks.unet import OVRUNet
from ICL.code.networks.unet_icl import UNet_icl
def net_factory(net_type="unet", in_chns=1, class_num=2, mode = "train", tsne=0):
    if net_type == "unet" and mode == "train":
        net = UNet(in_chns=in_chns, class_num=class_num).cuda()
    # elif net_type == "deeplab" and mode == "train":
    #     net = deeplabv3.__dict__['DeepLabv3p'](in_channels=1, out_channels=2).cuda()
    #     init_weight(net.net.classifier, nn.init.kaiming_normal_,
    #                 nn.BatchNorm2d, 1e-5, 0.1,
    #                 mode='fan_in', nonlinearity='relu')
    elif net_type == "unet":
        net = UNet(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "enet":
        net = ENet(in_channels=in_chns, num_classes=class_num).cuda()
    elif net_type == "unet_ds":
        net = UNet_DS(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_cct":
        net = UNet_CCT(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_urpc":
        net = UNet_URPC(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_ssnet":
        net = SSNet(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_pcl":
        net = SAMT_PCL(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "UNet_contr":
        net = UNet_contr(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "UNet_BMT_DCCL":
        net = UNet_BMT_DCCL(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_fea_aux":
        net = UNet_fea_aux(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_sdf":
        net = UNet_DTC(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_cml":
        net = unet.UNet(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_dcnet":
        net = MCNet2d_KD(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_acmt":
        net = UNetacmt(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_cgs":
        net = OVRUNet(in_chns=in_chns, class_num=class_num).cuda()
    elif net_type == "unet_icl":
        net = UNet_icl(in_chns=in_chns, class_num=class_num).cuda()
    return net

def BCP_net(in_chns=1, class_num=2, ema=False):
    net = UNet_2d(in_chns=in_chns, class_num=class_num).cuda()
    if ema:
        for param in net.parameters():
            param.detach_()
    return net
def deeplab(in_chns=1, class_num=2,ema=False):
    net = deeplabv3.__dict__['DeepLabv3p'](in_channels=in_chns, out_channels=class_num).cuda()
    init_weight(net.net.classifier, nn.init.kaiming_normal_,
                nn.BatchNorm2d, 1e-5, 0.1,
                mode='fan_in', nonlinearity='relu')
    if ema:
        for param in net.parameters():
            param.detach_()
    return net

