import argparse
import os
import shutil

import cv2
import h5py
import numpy as np
import SimpleITK as sitk
import torch
from medpy import metric
from scipy.ndimage import zoom
from scipy.ndimage.interpolation import zoom
from tqdm import tqdm
from seg_sec.ABD_main_me.code.networks.config import get_config
from seg_sec.ABD_main_me.code.networks.net_factory import net_factory, BCP_net
# from BCP_main.BCPrun.code.networks.net_factory import BCP_net, net_factory
# from MCF.code.networks.unet import UNet
# from models import deeplabv3
# from ssseg.ABD_main_me.code.networks.vision_transformer import SwinUnet as ViT_seg

from PIL import Image

# from SSL4MIS_master.code.networks.vision_transformer import SwinUnet as ViT_seg
# from SSL4MIS_master.code.config import get_config
from SDCL.code.networks.net_factory import BCP_net
# from CauSSL.CauSSLmain.networks.vnet import VNet_mct
# from MiDSS_master.code.networks.unet_model import UNet
import torch.nn.functional as F
# from GraphCL.main.networks.net_factory import GraphCL
a = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/ISIC'
b = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/Thyroid Dataset all'
c = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/BUSI'
d = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/DDTI'
e = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/TUD'
f = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/PKTN'
g = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/DDTI_GroupedSplit'
h = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/TUD_GroupedSplit'
i = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/PKTN_GroupedSplit2'
parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default=i, help='Name of Experiment')
parser.add_argument('--exp', type=str,
                    default='0.05test', help='train_ACDC_Cross_Teaching/BCPrun')
parser.add_argument('--gpu', type=str,  default='0', help='GPU to use')
# parser.add_argument('--model_1', type=str,
#                     default='unet', help='model_name')
# parser.add_argument('--model_2', type=str,
#                     default='swin_unet', help='model_name')
parser.add_argument('--model_1', type=str,
                    default='unet_cgs', help='model_name')
parser.add_argument('--model_2', type=str,
                    default='unet', help='model_name')
parser.add_argument('--num_classes', type=int, default=2,
                    help='output channel of network')
parser.add_argument('--labeled_num', type=int, default=0.05,
                    help='labeled data')
parser.add_argument('--image_size', type=list, default=[256, 256],
                    help='patch size of network input')
parser.add_argument('--cfg', type=str,
                    default="/media/pc/2BAD0185185A06FD/Czk/ssseg/ABD_main_me/code/configs/swin_tiny_patch4_window7_224_lite.yaml",
                    help='path to config file', )
parser.add_argument("--opts", help="Modify config options by adding 'KEY VALUE' pairs. ",
                    default=None, nargs='+', )
parser.add_argument('--batch_size', type=int, default=1,
                    help='batch_size per gpu')
parser.add_argument('--zip', action='store_true',
                    help='use zipped dataset instead of folder dataset')
parser.add_argument('--cache-mode', type=str, default='part', choices=['no', 'full', 'part'],
                    help='no: no cache, ''full: cache all data, ''part: sharding the dataset into nonoverlapping pieces and only cache one piece')
parser.add_argument('--resume', help='resume from checkpoint')
parser.add_argument('--accumulation-steps', type=int,
                    help="gradient accumulation steps")
parser.add_argument('--use-checkpoint', action='store_true',
                    help="whether to use gradient checkpointing to save memory")
parser.add_argument('--amp-opt-level', type=str, default='O1', choices=['O0', 'O1', 'O2'],
                    help='mixed precision opt level, if O0, no amp is used')
parser.add_argument('--tag', help='tag of experiment')
parser.add_argument('--eval', action='store_true',
                    help='Perform evaluation only')
parser.add_argument('--throughput', action='store_true',
                    help='Test throughput only')
parser.add_argument('--patch_size', type=list,  default=[224, 224],
                    help='patch size of network input')
args = parser.parse_args()
config = get_config(args)

def plot_mask(img, masks, colors=None, alpha=0.5) -> np.ndarray:
    """Visualize segmentation mask.

     Parameters
     ----------
     img: numpy.ndarray
         Image with shape `(H, W, 3)`.
     masks: numpy.ndarray
         Binary images with shape `(N, H, W)`.
     colors: numpy.ndarray
         color for mask, shape `(N, 3)`.
         if None, generate random color for mask
     alpha: float, optional, default 0.5
         Transparency of plotted mask

     Returns
     -------
     numpy.ndarray
         The image plotted with segmentation masks, shape `(H, W, 3)`

     """
    if colors is None:
        colors = np.random.random((masks.shape[0], 3)) * 255
    else:
        if colors.shape[0] < masks.shape[0]:
            raise RuntimeError(
                f"colors count: {colors.shape[0]} is less than masks count: {masks.shape[0]}"
            )
    for mask, color in zip(masks, colors):
        mask = np.stack([mask, mask, mask], -1)
        img = np.where(mask, img * (1 - alpha) + color * alpha, img)

    return img.astype(np.uint8)
def read_image_color(image_path, label_path, color_map):
    """
    :param image_path: 图像文件路径
    :param label_path: 标签文件路径
    :param color_map: 输入的颜色列表
    :returns:
    img: numpy.ndarray
         Image with shape `(H, W, 3)`.
     label_trans: numpy.ndarray
         Binary images with shape `(N, H, W)`.
     RGB_map: numpy.ndarray
         color for mask, shape `(N, 3)`.
    """

    if image_path.min() < 0:
        image_path = (image_path + 1) * 127.5
    elif image_path.max() < 1:
        image_path = image_path * 255

    img = image_path
    mask = label_path
    mask = mask[:, :, np.newaxis]
    # print(mask.shape)
    label_trans = mask.transpose(2, 0, 1)
    color_map[0], color_map[2] = color_map[2], color_map[0]
    RGB_map = np.array(color_map)
    RGB_map = RGB_map.T
    RGB_map = RGB_map[np.newaxis, :]
    # print(color_RGB.shape)
    return img, label_trans, RGB_map
def calculate_metric_percase(pred, gt):
    pred[pred > 0.5] = 1
    gt[gt > 0.5] = 1
    pred = pred.astype('uint8')
    gt = gt.astype('uint8')
    # gt = gt[0,:,:]
    # pred = pred[0, :, :]
    dice = metric.binary.dc(pred, gt)
    jc = metric.binary.jc(pred, gt)
    pre = metric.binary.precision(pred,gt)
    if pred.sum() > 1e-4:
        asd = metric.binary.asd(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
    else:
        asd = 100
        hd95 = 100
    return dice, hd95,jc,asd,pre

def test_single_volume(case, net, test_save_path, FLAGS,lens,idx,modelname):
    # h5f = h5py.File(FLAGS.root_path + "/data/{}.h5".format(case), 'r')
    test_save_path = "/media/pc/180A0B207684C9D9/parabla/ours0.05/img256/"
    if not os.path.exists(test_save_path):
        os.makedirs(test_save_path)

    path = FLAGS.root_path + '/TestDataset/images/{}'.format(case)
    # path2 = FLAGS.root_path + '/TestDataset/masks/{}'.format(case).replace('png','jpg')
    path2 = FLAGS.root_path + '/TestDataset/masks/{}'.format(case)



    img = Image.open(path).convert('L')
    mask = Image.open(path2).convert('L')
    img = img.resize((256, 256), Image.LANCZOS)
    mask = mask.resize((256, 256), Image.NEAREST)
    image = np.array(img)[np.newaxis, :]

    label = np.array(mask).astype('uint8')[np.newaxis, :]
    # a = cv2.imread(path,cv2.COLOR_GRAY2RGB)
    # b = cv2.imread(path2,cv2.IMREAD_GRAYSCALE)
    # image = cv2.imread(path,cv2.COLOR_GRAY2RGB)[np.newaxis, :]
    # label = cv2.imread(path2,cv2.IMREAD_GRAYSCALE)[np.newaxis, :]
    label = np.where(label > 128, 1, 0)

    prediction = np.zeros_like(label)


    for ind in range(image.shape[0]):
        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (256 / x, 256 / y), order=0)
        input = torch.from_numpy(slice).unsqueeze(0).unsqueeze(0).float().cuda()
        net.eval()
        with torch.no_grad():
            out_main = net(input)
            if len(out_main) > 1:
                out_main = out_main[0]

            out = torch.argmax(torch.softmax(out_main, dim=1), dim=1).squeeze(0)
            out = out.cpu().detach().numpy()
            pred = zoom(out, (x / 256, y / 256), order=0)
            prediction[ind] = pred
    # if np.sum(prediction == 1)==0:
    #     first_metric = 0,0,0,0
    # else:
    img = Image.open(path) #isic是三通道的
    img = img.resize((256, 256), Image.LANCZOS)


    first_metric = calculate_metric_percase(prediction == 1, label == 1)
    H1, W1 = 256, 256
    img = img.convert('RGB')
    image = np.array(img).astype('uint8')

    label = label.squeeze(0)
    prediction = prediction.squeeze(0)
    mask_color = [
        0, 0, 255
    ]  # 输入颜色数组为RGB格p式,这里只支持单类别的颜色设置，多类别的后续可能会改进出来
    mask_color_2 = [255, 0, 0]
    # label2[label2!=255]=255
    # _, label2 = cv2.threshold(label, 128, 255, cv2.THRESH_BINARY) #去除边缘噪声!!很关键
    image, label2, color_RGB = read_image_color(image, label, mask_color)
    label2 = plot_mask(image, label2, colors=color_RGB, alpha=0.5)
    label2, pred, color_RGB_2 = read_image_color(label2, prediction, mask_color_2)
    pred = plot_mask(label2, pred, colors=color_RGB_2, alpha=0.5)
    cv2.imwrite(test_save_path + case[:-4] + '_img.png', image)
    cv2.imwrite(test_save_path + case[:-4] + '_lbl.png',
                label2)
    cv2.imwrite(test_save_path + case[:-4] + '_prd.png',
                pred)
    print('itr/itrs: {}/{}'.format(idx, len(lens)))


    # if np.sum(prediction == 2)==0:
    #     second_metric = 0,0,0,0
    # else:
    #     second_metric = calculate_metric_percase(prediction == 2, label == 2)
    # if np.sum(prediction == 3)==0:
    #     third_metric = 0,0,0,0
    # else:
    #     third_metric = calculate_metric_percase(prediction == 3, label == 3)
    return first_metric

path = args.root_path + '/TestDataset/images/'
def Inference_model1(FLAGS):
    print("——Starting the Model1 Prediction——")
    # with open(FLAGS.root_path + '/test.list', 'r') as f:image_list =f.readlines()
    image_list = sorted([x for x in os.listdir(path)])
    # image_list = sorted([item.replace('\n', '').split(".")[0]for item in image_list])
    # snapshot_path = "/home/pc/Czk/ssseg/ABD_main/model/BCPrun/ACDC_{}_{}_labeled".format(FLAGS.exp, FLAGS.labeled_num)
    # test_save_path = "/home/pc/Czk/ssseg/ABD_main/model/BCPrun/ACDC_{}_{}_labeled/{}_pred[];\1/'
    # ][][
    snapshot_path = "/media/pc/2BAD0185185A06FD/Czk/seg_sec/ABD_main_me/model/BCP/thy_{}_{}_labeled/self_train".format(FLAGS.exp, FLAGS.labeled_num)
    test_save_path = "/media/pc/180A0B207684C9D9/parabla/ours0.05/self_train/unet_predictions_model/"
    if not os.path.exists(test_save_path):
        os.makedirs(test_save_path)

    net = net_factory(net_type=FLAGS.model_1, in_chns=1,class_num=FLAGS.num_classes)
    # net = ViT_seg(config, img_size=args.patch_size,
    #                  num_classes=args.num_classes).cuda()
    # net.load_from(config)
    net = BCP_net( in_chns=1, class_num=FLAGS.num_classes)

    # net = BCP_net(model="ResUNet", in_chns=1, class_num=2)
    # net = GraphCL(in_chns=1, class_num=2, cluster_num=2)
    # net = UNet(in_chns=1, class_num=FLAGS.num_classes).cuda()
    # net = VNet_mct(n_channels=1, n_classes=FLAGS.num_classes, normalization='batchnorm', has_dropout=False).cuda()
    # net = deeplab(in_/home/pc/Czk/ssseg/ABD_main_me/model/BCP/thy_Unet_swcpsswapcat60000_0.05_labeled/self_train/model1_iter_55800_dice_0.7421.pthchns=1, class_num=FLAGS.num_classes)
    # save_model_path = os.path.join(snapshot_path, '{}_best_model1.pth'.format(FLAGS.model_1))

    save_model_path = '/home/pc/Czk/SDCL/code/model/thy_pktnfold5_0.1_labeled/self_train/model2_iter_15200_dice_0.8738.pth'
    checkpoint = torch.load(save_model_path)
    net.load_state_dict(checkpoint, strict=False)
    print("Loaded weights from {}, missing keys: {}".format(
        save_model_path, [k for k in net.state_dict() if k not in checkpoint]))
    net.eval()

    # """cgs"""
    # checkpoint_path = '/home/pc/Czk/CGS/model/pktnfold3_0.1/OVRUNet/model_iter_29200_dice_0.8557.pth'
    # checkpoint = torch.load(checkpoint_path, map_location='cuda')  # 或者 map_location='cpu'
    #
    # # 提取模型权重，注意键名可能为 'model_state_dict' 或 'model'
    # if 'model_state_dict' in checkpoint:
    #     state_dict = checkpoint['model_state_dict']
    # elif 'model' in checkpoint:
    #     state_dict = checkpoint['model']
    # elif 'state_dict' in checkpoint:
    #     state_dict = checkpoint['state_dict']
    # else:
    #     # 如果直接保存的是模型权重（不是字典），则直接使用 checkpoint
    #     state_dict = checkpoint# checkpoint_path = '/media/pc/2BAD0185185A06FD/Czk/CGS/model/tn3k_0.1/OVRUNet/model_iter_53000_dice_0.7349.pth'
    # checkpoint = torch.load(checkpoint_path, map_location='cuda')  # 或者 map_location='cpu'
    #
    # # 提取模型权重，注意键名可能为 'model_state_dict' 或 'model'
    # if 'model_state_dict' in checkpoint:
    #     state_dict = checkpoint['model_state_dict']
    # elif 'model' in checkpoint:
    #     state_dict = checkpoint['model']
    # elif 'state_dict' in checkpoint:
    #     state_dict = checkpoint['state_dict']
    # else:
    #     # 如果直接保存的是模型权重（不是字典），则直接使用 checkpoint
    #     state_dict = checkpoint
    #
    # # 加载权重，忽略不匹配的键（strict=False）
    # net.load_state_dict(state_dict, strict=False)
    # print("Loaded model from {}".format(checkpoint_path))
    #
    # # 可选：查看缺失的键（如果有些层没被保存）
    # missing_keys = [k for k in net.state_dict() if k not in state_dict]
    # print("Missing keys (will be randomly initialized):", missing_keys)
    #
    # # 切换到评估模式
    # net.eval()
    # net.cuda()  # 如果有 GPU

    first_total = 0.0
    second_total = 0.0
    third_total = 0.0
    i = 1
    for case in tqdm(image_list):
        first_metric = test_single_volume(case, net, test_save_path, FLAGS,image_list,i,FLAGS.model_1+'1')

        first_total += np.asarray(first_metric)
        i += 1
    avg_metric = [first_total / len(image_list)]
    average = avg_metric[0]
    print(avg_metric)
    print(f'average:{average}')
    with open(os.path.join(test_save_path, 'performance.txt'), 'w') as file:
        file.write(str(avg_metric) + '\n')
        file.write(str(average) + '\n')
    return avg_metric

if __name__ == '__main__':
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
    FLAGS = parser.parse_args()
    metric_model1 = Inference_model1(FLAGS)
    # metric_model2 = Inference_model2(FLAGS)