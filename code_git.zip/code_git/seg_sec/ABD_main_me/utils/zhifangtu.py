import torch
import numpy as np
import cv2
import warnings

warnings.filterwarnings('ignore')


def histogram_matching(source_img, target_img, num_bins=256):
    """
    改进的直方图匹配：使用CDF映射方法

    参数:
        source_img: 源图像张量，形状为 [C, H, W] 或 [1, C, H, W]
        target_img: 目标图像张量，形状与source_img相同
        num_bins: 直方图的bin数量

    返回:
        匹配后的图像张量
    """
    # 确保输入形状一致
    if source_img.dim() == 4:
        source_img = source_img.squeeze(0)  # [1, C, H, W] -> [C, H, W]
    if target_img.dim() == 4:
        target_img = target_img.squeeze(0)  # [1, C, H, W] -> [C, H, W]

    # 获取设备信息
    device = source_img.device

    # 获取通道数
    num_channels = source_img.shape[0]
    matched_channels = []

    for c in range(num_channels):
        # 获取当前通道
        source_channel = source_img[c]
        target_channel = target_img[c]

        # 转换为numpy数组（CPU上处理）
        source_np = source_channel.cpu().numpy()
        target_np = target_channel.cpu().numpy()

        # 归一化到[0, 1]范围
        source_min, source_max = source_np.min(), source_np.max()
        target_min, target_max = target_np.min(), target_np.max()

        source_norm = (source_np - source_min) / (source_max - source_min + 1e-8)
        target_norm = (target_np - target_min) / (target_max - target_min + 1e-8)

        # 计算源图像直方图和CDF
        source_hist, source_bins = np.histogram(source_norm.flatten(), bins=num_bins, range=(0, 1))
        source_cdf = source_hist.cumsum()
        source_cdf = source_cdf / source_cdf[-1]

        # 计算目标图像直方图和CDF
        target_hist, target_bins = np.histogram(target_norm.flatten(), bins=num_bins, range=(0, 1))
        target_cdf = target_hist.cumsum()
        target_cdf = target_cdf / target_cdf[-1]

        # 创建映射表（查找表）
        lut = np.zeros(num_bins, dtype=np.float32)
        for i in range(num_bins):
            # 找到目标CDF中大于等于源CDF[i]的最小索引
            j = 0
            while j < num_bins and source_cdf[i] > target_cdf[j]:
                j += 1
            if j == num_bins:
                j = num_bins - 1
            lut[i] = j / float(num_bins)

        # 将源图像值映射到bin索引
        bin_indices = np.digitize(source_norm.flatten(), source_bins[:-1]) - 1
        bin_indices = np.clip(bin_indices, 0, num_bins - 1)

        # 应用查找表
        matched_flat = lut[bin_indices]

        # 恢复形状并反归一化
        matched_norm = matched_flat.reshape(source_np.shape)
        matched_img = matched_norm * (source_max - source_min) + source_min

        # 转换为张量
        matched_tensor = torch.from_numpy(matched_img).to(device)
        matched_channels.append(matched_tensor.unsqueeze(0))

    # 合并通道
    matched_img = torch.cat(matched_channels, dim=0)
    return matched_img


def histogram_matching_opencv(source_img, target_img):
    """
    使用OpenCV实现的直方图匹配（更高效）

    参数:
        source_img: 源图像张量，形状为 [C, H, W] 或 [1, C, H, W]
        target_img: 目标图像张量，形状与source_img相同

    返回:
        匹配后的图像张量
    """
    # 确保输入形状一致
    if source_img.dim() == 4:
        source_img = source_img.squeeze(0)
    if target_img.dim() == 4:
        target_img = target_img.squeeze(0)

    device = source_img.device
    num_channels = source_img.shape[0]
    matched_channels = []

    for c in range(num_channels):
        source_channel = source_img[c]
        target_channel = target_img[c]

        # 转换为numpy
        source_np = source_channel.cpu().numpy()
        target_np = target_channel.cpu().numpy()

        # 保存原始范围
        source_min, source_max = source_np.min(), source_np.max()
        target_min, target_max = target_np.min(), target_np.max()

        # 归一化到0-255范围
        if source_max <= 1.0:
            source_uint8 = (source_np * 255).astype(np.uint8)
        else:
            source_uint8 = np.clip(source_np, 0, 255).astype(np.uint8)

        if target_max <= 1.0:
            target_uint8 = (target_np * 255).astype(np.uint8)
        else:
            target_uint8 = np.clip(target_np, 0, 255).astype(np.uint8)

        # 使用OpenCV直方图匹配
        # 计算直方图
        src_hist = cv2.calcHist([source_uint8], [0], None, [256], [0, 256])
        src_cdf = np.cumsum(src_hist) / source_uint8.size

        tgt_hist = cv2.calcHist([target_uint8], [0], None, [256], [0, 256])
        tgt_cdf = np.cumsum(tgt_hist) / target_uint8.size

        # 创建查找表
        lut = np.zeros(256, dtype=np.uint8)
        for i in range(256):
            idx = np.argmin(np.abs(tgt_cdf - src_cdf[i]))
            lut[i] = idx

        # 应用查找表
        matched_uint8 = cv2.LUT(source_uint8, lut)

        # 转换回原始范围
        if source_max <= 1.0:
            matched_img = matched_uint8.astype(np.float32) / 255.0
        else:
            matched_img = matched_uint8.astype(np.float32)

        matched_tensor = torch.from_numpy(matched_img).to(device)
        matched_channels.append(matched_tensor.unsqueeze(0))

    matched_img = torch.cat(matched_channels, dim=0)
    return matched_img


def adaptive_histogram_equalization(img, clip_limit=2.0, grid_size=(8, 8), color_space='RGB'):
    """
    改进的自适应直方图均衡化 (CLAHE)

    参数:
        img: 输入图像张量，形状为 [C, H, W]
        clip_limit: 对比度限制阈值
        grid_size: 网格大小 (rows, cols)
        color_space: 颜色空间，'RGB' 或 'LAB'（对彩色图像效果更好）

    返回:
        均衡化后的图像
    """
    # 确保是3D张量
    if img.dim() == 4:
        img = img.squeeze(0)

    device = img.device

    # 转换为numpy数组
    img_np = img.cpu().numpy()

    # 保存原始范围
    img_min, img_max = img_np.min(), img_np.max()

    # 归一化到0-255范围
    if img_max <= 1.0:
        img_norm = (img_np - img_min) / (img_max - img_min + 1e-8)
        img_uint8 = (img_norm * 255).astype(np.uint8)
    else:
        img_norm = np.clip((img_np - img_min) / (img_max - img_min + 1e-8), 0, 1)
        img_uint8 = (img_norm * 255).astype(np.uint8)

    # 转换形状
    if img_uint8.shape[0] == 1:  # 单通道
        img_uint8 = img_uint8.squeeze(0)
        is_grayscale = True
    else:  # 多通道
        img_uint8 = np.transpose(img_uint8, (1, 2, 0))
        is_grayscale = False

    # 创建CLAHE对象
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)

    # 应用CLAHE
    if is_grayscale:
        # 单通道图像
        enhanced_uint8 = clahe.apply(img_uint8)
    else:
        # 彩色图像
        if color_space == 'LAB':
            # 转换到LAB空间，对L通道进行CLAHE
            lab = cv2.cvtColor(img_uint8, cv2.COLOR_RGB2LAB)
            l, a, b = cv2.split(lab)
            l_enhanced = clahe.apply(l)
            enhanced_lab = cv2.merge([l_enhanced, a, b])
            enhanced_uint8 = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2RGB)
        else:
            # 在RGB空间对每个通道分别应用CLAHE
            enhanced_channels = []
            for c in range(3):
                enhanced_channel = clahe.apply(img_uint8[:, :, c])
                enhanced_channels.append(enhanced_channel)
            enhanced_uint8 = np.stack(enhanced_channels, axis=2)

    # 转换回0-1范围
    enhanced_norm = enhanced_uint8.astype(np.float32) / 255.0

    # 反归一化到原始范围
    enhanced_img = enhanced_norm * (img_max - img_min) + img_min

    # 转换回PyTorch张量
    if is_grayscale:
        enhanced_tensor = torch.from_numpy(enhanced_img).unsqueeze(0)  # [H, W] -> [1, H, W]
    else:
        enhanced_tensor = torch.from_numpy(np.transpose(enhanced_img, (2, 0, 1)))  # [H, W, C] -> [C, H, W]

    enhanced_tensor = enhanced_tensor.to(device)
    return enhanced_tensor


def enhance_min_to_max(min_img, max_img, method='hist_match', **kwargs):
    """
    改进的图像增强：将最小熵图像增强到最大熵图像的对比度

    参数:
        min_img: 最小熵图像 [C, H, W] 或 [1, C, H, W]
        max_img: 最大熵图像 [C, H, W] 或 [1, C, H, W]
        method: 增强方法，可选 'hist_match', 'hist_match_opencv', 'clahe', 'gamma', 'linear_stretch', 'hybrid'
        **kwargs: 各方法的额外参数

    返回:
        增强后的图像
    """
    # 确保是3D张量
    if min_img.dim() == 4:
        min_img = min_img.squeeze(0)
    if max_img.dim() == 4:
        max_img = max_img.squeeze(0)

    # 确保图像在合理范围内
    min_img = (min_img - min_img.min()) / (min_img.max() - min_img.min() + 1e-8)
    max_img = (max_img - max_img.min()) / (max_img.max() - max_img.min() + 1e-8)

    if method == 'hist_match':
        # 直方图匹配（自定义实现）
        num_bins = kwargs.get('num_bins', 256)
        enhanced_img = histogram_matching(min_img, max_img, num_bins)

    elif method == 'hist_match_opencv':
        # 直方图匹配（OpenCV实现）
        enhanced_img = histogram_matching_opencv(min_img, max_img)

    elif method == 'clahe':
        # 自适应直方图均衡化
        clip_limit = kwargs.get('clip_limit', 2.0)
        grid_size = kwargs.get('grid_size', (8, 8))
        color_space = kwargs.get('color_space', 'RGB')
        enhanced_img = adaptive_histogram_equalization(
            min_img, clip_limit, grid_size, color_space
        )

    elif method == 'gamma':
        # Gamma校正 - 改进版本
        # 使用分位数计算gamma值，避免极端值影响
        min_median = torch.median(min_img)
        max_median = torch.median(max_img)

        # 计算gamma值
        gamma = max_median / (min_median + 1e-8)

        # 限制gamma范围并平滑调整
        gamma_min = kwargs.get('gamma_min', 0.1)
        gamma_max = kwargs.get('gamma_max', 5.0)
        gamma = torch.clamp(gamma, gamma_min, gamma_max)

        # 应用Gamma校正
        enhanced_img = torch.pow(min_img, gamma)

    elif method == 'linear_stretch':
        # 线性拉伸 - 改进版本
        # 使用分位数而不是最小最大值，避免噪声影响
        min_low = torch.quantile(min_img, 0.01)
        min_high = torch.quantile(min_img, 0.99)

        max_low = torch.quantile(max_img, 0.01)
        max_high = torch.quantile(max_img, 0.99)

        # 线性变换
        enhanced_img = (min_img - min_low) / (min_high - min_low + 1e-8)
        enhanced_img = enhanced_img * (max_high - max_low) + max_low
        enhanced_img = torch.clamp(enhanced_img, 0, 1)

    elif method == 'hybrid':
        # 混合方法：先CLAHE，再直方图匹配
        # 应用CLAHE
        clip_limit = kwargs.get('clip_limit', 2.0)
        grid_size = kwargs.get('grid_size', (8, 8))
        color_space = kwargs.get('color_space', 'RGB')
        clahe_img = adaptive_histogram_equalization(min_img, clip_limit, grid_size, color_space)

        # 直方图匹配
        num_bins = kwargs.get('num_bins', 256)
        enhanced_img = histogram_matching(clahe_img, max_img, num_bins)

    elif method == 'adaptive_gamma':
        # 自适应Gamma校正
        patch_size = kwargs.get('patch_size', 32)
        h, w = min_img.shape[1], min_img.shape[2]

        enhanced_img = torch.zeros_like(min_img)

        for i in range(0, h, patch_size):
            for j in range(0, w, patch_size):
                i_end = min(i + patch_size, h)
                j_end = min(j + patch_size, w)

                # 提取图像块
                patch_min = min_img[:, i:i_end, j:j_end]
                patch_max = max_img[:, i:i_end, j:j_end]

                if patch_min.numel() > 0:
                    # 计算局部gamma
                    min_mean = torch.mean(patch_min)
                    max_mean = torch.mean(patch_max)
                    gamma = max_mean / (min_mean + 1e-8)
                    gamma = torch.clamp(gamma, 0.5, 2.0)

                    # 应用gamma校正
                    patch_enhanced = torch.pow(patch_min, gamma)
                    enhanced_img[:, i:i_end, j:j_end] = patch_enhanced

    else:
        raise ValueError(f"未知的增强方法: {method}")

    return enhanced_img.unsqueeze(0)  # 添加批次维度