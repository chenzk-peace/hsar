import os
import numpy as np
from skimage import measure


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def dice_score(prediction, target):
    smooth = 1e-5
    num_classes = target.size(0)
    prediction = prediction.view(num_classes, -1)
    target = target.view(num_classes, -1)

    intersection = (prediction * target)

    dice = (2. * intersection.sum(1) + smooth) / (prediction.sum(1) + target.sum(1) + smooth)

    return dice


from medpy import metric


def dice_score_batch(prediction, target):
    smooth = 1e-5
    batchsize = target.size(0)
    num_classes = target.size(1)
    prediction = prediction.view(batchsize, num_classes, -1)
    target = target.view(batchsize, num_classes, -1)
    intersection = (prediction * target)
    a = intersection.sum(2)
    dice = (2. * intersection.sum(2) + smooth) / (prediction.sum(2) + target.sum(2) + smooth)
    return dice


import torch
from scipy.ndimage.morphology import distance_transform_edt as edt
import medpy


class HausdorffDistance:
    def hd_distance(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        # if not np.any(x):
        #     x[0][0] = 1.0
        # elif not np.any(y):
        #     y[0][0] = 1.0

        indexes = np.nonzero(x)
        distances = edt(np.logical_not(y))

        return np.array(np.percentile(distances[indexes], 95))

    def compute(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:

        pred1 = pred[:, 0, :, :]
        pred2 = pred[:, 1, :, :]
        pred3 = pred1.squeeze(0).cpu().numpy()
        pred4 = pred2.squeeze(0).cpu().numpy()


        target1 = target[:, 0, :, :]
        target2 = target[:, 1, :, :]
        target3 = target1.squeeze(0).cpu().numpy()
        target4 = target2.squeeze(0).cpu().numpy()


        pred1 = (pred1 > 0.5).byte()
        target1 = (target1 > 0.5).byte()
        pred2 = (pred2 > 0.5).byte()
        target2 = (target2 > 0.5).byte()
        if torch.sum(pred2).float() < 1e-4:
            # pred2[0][0][0] = 1
            hd2 = 100
            asd2 = 100
        else:
            hd2 = medpy.metric.hd95(pred2.cpu().numpy(), target2.cpu().numpy())
            asd2 = medpy.metric.asd(pred2.cpu().numpy(), target2.cpu().numpy())
        target1, target2, pred1, pred2 = target1.cpu().numpy(), target2.cpu().numpy(), pred1.cpu().numpy(), pred2.cpu().numpy()
        hd1 = medpy.metric.hd95(pred1, target1)

        jc1 = medpy.metric.jc(pred1, target1)
        jc2 = medpy.metric.jc(pred2, target2)
        asd1 = medpy.metric.asd(pred1, target1)

        dc1 = medpy.metric.dc(pred1, target1)
        dc2 = medpy.metric.dc(pred2, target2)
        prec2 = medpy.metric.precision(pred2, target2)
        spec2 = medpy.metric.specificity(pred2, target2)
        sen2 = medpy.metric.sensitivity(pred2, target2)
        ppv = medpy.metric.positive_predictive_value(pred2, target2)
        # pred3 = pred[:, 0, :, :]
        # pred4 = pred[:, 1, :, :]
        # target3 = target[:, 0, :, :]
        # target4 = target[:, 1, :, :]
        # pred3 = (pred3 > 0.5).byte()
        # target3 = (target3 > 0.5).byte()
        # if torch.sum(pred3) == 0:
        #     pred1[0][0][0][0] = 1

        # right_hd = torch.from_numpy(
        #     self.hd_distance(pred3.cpu().numpy(), target3.cpu().numpy())
        #     ).float()
        #
        # left_hd = torch.from_numpy(
        #     self.hd_distance(target3.cpu().numpy(), pred3.cpu().numpy())
        #     ).float()
        #
        # pred4 = (pred4 > 0.5).byte()
        # target4 = (target4 > 0.5).byte()
        # if torch.sum(pred4) == 0:
        #     pred4[0][0][0][0] = 1
        #
        # right_hd2 = torch.from_numpy(
        #     self.hd_distance(pred4.cpu().numpy(), target4.cpu().numpy())
        # ).float()
        #
        # left_hd2 = torch.from_numpy(
        #     self.hd_distance(target4.cpu().numpy(), pred4.cpu().numpy())
        # ).float()

        # return (torch.max(right_hd, left_hd)+torch.max(right_hd2, left_hd2))/2
        return hd2, jc2, asd2, dc2, prec2, spec2, sen2, ppv


hd_metric = HausdorffDistance()


def measure_img(o_img, t_num=1):
    p_img = np.zeros_like(o_img)
    testa1 = measure.label(o_img.astype("bool"))
    props = measure.regionprops(testa1)
    numPix = []
    for ia in range(len(props)):
        numPix += [props[ia].area]
    for i in range(0, t_num):
        index = numPix.index(max(numPix)) + 1
        p_img[testa1 == index] = o_img[testa1 == index]
        numPix[index - 1] = 0
    return p_img
