import torch
import random
import numpy as np
from collections import deque
from scipy.spatial.distance import cosine
import warnings
from sklearn.metrics.pairwise import cosine_similarity
warnings.filterwarnings('ignore')


class WeightedHistoricalMinImageBank:
    """
    带权重的历史最小熵图像存储系统
    基于熵值给予不同选择权重，支持多种选择策略
    """

    def __init__(self, max_size=10, num_models=2, selection_strategy='weighted',
                 entropy_coeff=0.5, similarity_coeff=0.5):
        """
        初始化历史图像存储系统

        参数:
            max_size: 每个模型存储的最大图像数量
            num_models: 模型数量
            selection_strategy: 选择策略
                'uniform': 均匀随机
                'weighted': 基于熵值加权（熵值越低，权重越高）
                'recent': 偏好最近的历史图像
                'diverse': 偏好与当前图像不同的历史图像
                'hybrid': 混合策略
            diversity_weight: 多样性权重（用于'diverse'和'hybrid'策略）
            recent_bias: 最近偏置权重（用于'hybrid'策略）
        """
        self.max_size = max_size
        self.num_models = num_models
        self.selection_strategy = selection_strategy
        self.entropy_coeff = entropy_coeff
        self.similarity_coeff = similarity_coeff


        # 为每个模型创建独立的存储队列
        self.historical_min_images = [deque(maxlen=max_size) for _ in range(num_models)]
        self.historical_entropies = [deque(maxlen=max_size) for _ in range(num_models)]
        self.historical_features = [deque(maxlen=max_size) for _ in range(num_models)]
        self.batch_info = [deque(maxlen=max_size) for _ in range(num_models)]

        # 统计信息
        self.selection_counts = [0 for _ in range(num_models)]
        self.total_selections = 0

    def compute_image_features(self, img_tensor):
        """
        计算图像特征（用于多样性选择）

        参数:
            img_tensor: 图像张量 [1, C, H, W]

        返回:
            特征向量
        """
        # 简化特征：使用均值和标准差
        if img_tensor.dim() == 4:
            img = img_tensor.squeeze(0)
        else:
            img = img_tensor

        # 计算每个通道的均值和标准差
        features = []
        for c in range(img.shape[0]):
            channel = img[c]
            features.append(torch.mean(channel).item())
            features.append(torch.std(channel).item())

        # 添加全局统计
        features.append(torch.mean(img).item())
        features.append(torch.std(img).item())

        return np.array(features)

    def add_min_images(self, model_idx, min_img, entropy, current_max_img=None, batch_info=None):
        """
        添加最小熵图像到历史记录

        参数:
            model_idx: 模型索引 (0或1)
            min_img: 最小熵图像张量
            entropy: 对应的熵值
            current_max_img: 当前的最大熵图像（用于计算特征对比）
            batch_info: 批次信息
        """
        # 确保存储的是张量的副本
        img_clone = min_img.detach().clone()
        self.historical_min_images[model_idx].append(img_clone)
        self.historical_entropies[model_idx].append(float(entropy))

        # 计算图像特征
        features = self.compute_image_features(img_clone)
        self.historical_features[model_idx].append(features)

        if batch_info is not None:
            self.batch_info[model_idx].append(batch_info)

        # 如果历史记录已满，移除最旧的特征
        if len(self.historical_features[model_idx]) > self.max_size:
            self.historical_features[model_idx].popleft()

    def get_weighted_min_image(self, model_idx, current_max_img=None, default_img=None):
        """
        根据策略获取历史最小熵图像

        参数:
            model_idx: 模型索引
            current_max_img: 当前最大熵图像（用于多样性计算）
            default_img: 默认图像（历史为空时返回）

        返回:
            选择的历史图像张量
        """
        if len(self.historical_min_images[model_idx]) == 0:
            if default_img is not None:
                return default_img
            else:
                raise ValueError(f"模型 {model_idx} 的历史记录为空")

        # 更新选择统计
        self.selection_counts[model_idx] += 1
        self.total_selections += 1

        if self.selection_strategy == 'uniform':
            # 均匀随机选择
            idx = random.randint(0, len(self.historical_min_images[model_idx]) - 1)
            return self.historical_min_images[model_idx][idx].clone()

        elif self.selection_strategy == 'weighted':
            # 基于熵值加权选择（熵值越低，权重越高）
            entropies = np.array(list(self.historical_entropies[model_idx]))

            # 避免熵值为0导致权重无穷大
            entropies = np.maximum(entropies, 1e-8)

            # 计算权重：熵值越低，权重越高
            weights = 1.0 / entropies

            # 归一化权重
            weights = weights / weights.sum()

            # 根据权重选择
            idx = np.random.choice(len(self.historical_min_images[model_idx]), p=weights)
            return self.historical_min_images[model_idx][idx].clone()



        elif self.selection_strategy == 'diverse':
            # 偏好与当前最大熵图像不同的历史图像
            if current_max_img is None:
                # 如果没有当前图像，退回到加权选择
                return self.get_weighted_min_image(model_idx, None, default_img)

            # 计算当前最大熵图像的特征
            current_features = self.compute_image_features(current_max_img)

            # 计算每个历史图像与当前图像的相似度
            similarities = []
            for hist_features in self.historical_features[model_idx]:
                # 使用余弦相似度
                similarity = cosine(hist_features, current_features)
                similarities.append(similarity)

            similarities = np.array(similarities)

            # 相似度越高（越相似），权重越高
            weights = similarities
            weights = np.maximum(weights, 0.1)  # 确保最小权重

            # 归一化
            weights = weights / weights.sum()

            idx = np.random.choice(len(self.historical_min_images[model_idx]), p=weights)
            return self.historical_min_images[model_idx][idx].clone()

        elif self.selection_strategy == 'hybrid':
            # 混合策略：结合熵值和多样性
            n = len(self.historical_min_images[model_idx])

            # 1. 基于熵值的权重
            entropies = np.array(list(self.historical_entropies[model_idx]))
            entropies = np.maximum(entropies, 1e-8)
            entropy_weights = np.exp(-entropies)

            # 2. 基于相似性的权重（如果提供了当前图像）
            if current_max_img is not None:
                current_features = self.compute_image_features(current_max_img)
                similarities = []
                for hist_features in self.historical_features[model_idx]:
                    # 计算余弦相似度
                    similarity = cosine_similarity(hist_features.reshape(1, -1), current_features.reshape(1, -1))[0][0]
                    similarities.append(similarity)

                similarity_weights = np.array(similarities)
                # 确保非负，因为余弦相似度可能为负，但我们希望相似性权重非负
                similarity_weights = np.maximum(similarity_weights, 0)
            else:
                similarity_weights = np.zeros(n)

            # 分别归一化
            entropy_weights_norm = entropy_weights / (entropy_weights.sum() + 1e-8)
            similarity_weights_norm = similarity_weights / (similarity_weights.sum() + 1e-8)

            # 组合权重：使用可调节的系数，默认相似性权重占主导
            # 如果没有当前图像，则similarity_weights_norm全为0，那么组合权重就是熵值权重
            weights = (entropy_weights_norm * self.entropy_coeff +
                       similarity_weights_norm * self.similarity_coeff)

            # 再次归一化
            weights = weights / (weights.sum() + 1e-8)

            idx = np.random.choice(n, p=weights)
            return self.historical_min_images[model_idx][idx].clone()

        else:
            raise ValueError(f"未知的选择策略: {self.selection_strategy}")

    def get_pair_with_diversity(self, model_idx1, model_idx2, current_max_img,
                                min_diversity=0.3, max_attempts=5):
        """
        获取多样性的图像对（避免两个模型选择过于相似的图像）

        参数:
            model_idx1: 第一个模型索引
            model_idx2: 第二个模型索引
            current_max_img: 当前最大熵图像
            min_diversity: 最小多样性阈值
            max_attempts: 最大尝试次数

        返回:
            (min_img1, min_img2) 图像对
        """
        # 确保两个模型都有历史记录
        if (len(self.historical_min_images[model_idx1]) == 0 or
                len(self.historical_min_images[model_idx2]) == 0):
            return self.get_random_pair(model_idx1, model_idx2, None, None)

        for attempt in range(max_attempts):
            # 分别选择图像
            img1 = self.get_weighted_min_image(model_idx1, current_max_img)
            img2 = self.get_weighted_min_image(model_idx2, current_max_img)

            # 计算两个图像之间的多样性
            features1 = self.compute_image_features(img1)
            features2 = self.compute_image_features(img2)
            diversity = 1 - cosine(features1, features2)

            # 检查是否满足多样性要求
            if diversity < min_diversity or attempt == max_attempts - 1:
                return img1, img2

        # 如果多次尝试仍不满足，返回最后一次尝试的结果
        return img1, img2

    def get_random_pair(self, model_idx1, model_idx2, default_img1=None, default_img2=None):
        """
        随机获取两个模型的历史最小熵图像对

        返回:
            (min_img1, min_img2) 图像对
        """
        min_img1 = self.get_weighted_min_image(model_idx1, None, default_img1)
        min_img2 = self.get_weighted_min_image(model_idx2, None, default_img2)

        return min_img1, min_img2

    def clear(self, model_idx=None):
        """
        清空历史记录

        参数:
            model_idx: 如果为None，清空所有模型；否则清空指定模型
        """
        if model_idx is None:
            for i in range(self.num_models):
                self.historical_min_images[i].clear()
                self.historical_entropies[i].clear()
                self.historical_features[i].clear()
                self.batch_info[i].clear()
                self.selection_counts[i] = 0
        else:
            self.historical_min_images[model_idx].clear()
            self.historical_entropies[model_idx].clear()
            self.historical_features[model_idx].clear()
            self.batch_info[model_idx].clear()
            self.selection_counts[model_idx] = 0

        self.total_selections = 0

    def get_stats(self):
        """
        获取系统统计信息

        返回:
            统计信息字典
        """
        stats = {
            'total_selections': self.total_selections,
            'selection_counts': self.selection_counts.copy(),
            'model_stats': []
        }

        for i in range(self.num_models):
            model_stat = {
                'model_idx': i,
                'history_size': len(self.historical_min_images[i]),
                'avg_entropy': np.mean(list(self.historical_entropies[i])) if self.historical_entropies[i] else 0,
                'min_entropy': np.min(list(self.historical_entropies[i])) if self.historical_entropies[i] else 0,
                'max_entropy': np.max(list(self.historical_entropies[i])) if self.historical_entropies[i] else 0,
                'selection_rate': self.selection_counts[i] / max(self.total_selections, 1)
            }
            stats['model_stats'].append(model_stat)

        return stats

    def get_all_images(self, model_idx):
        """
        获取指定模型的所有历史图像

        返回:
            所有存储的图像列表
        """
        return list(self.historical_min_images[model_idx])