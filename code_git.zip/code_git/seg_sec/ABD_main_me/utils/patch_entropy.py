import torch
import torch.nn.functional as F


def split_tensor_into_patches(tensor, patch_size=64, stride=64):
    """
    将四维张量高效分割成多个小块，支持批量和多通道。
    返回形状：(B, num_patches_h, num_patches_w, C, patch_size, patch_size)
    """
    batch_size, channels, height, width = tensor.shape
    patches = tensor.unfold(2, patch_size, stride).unfold(3, patch_size, stride)
    return patches.permute(0, 2, 3, 1, 4, 5).contiguous()  # (B, h_patches, w_patches, C, ph, pw)


def calculate_entropy(probability_patches, eps=1e-10):
    """
    高效计算每个小块的熵，支持批量和多通道。
    输入形状：(B, num_patches_h, num_patches_w, C, patch_size, patch_size)
    返回形状：(B, num_patches_h, num_patches_w)
    """
    # 展平每个patch为一维向量
    batch_size, h_patches, w_patches, channels, ph, pw = probability_patches.shape
    patches_flat = probability_patches.reshape(batch_size, h_patches, w_patches, -1)

    # 归一化并计算熵
    probs = F.normalize(patches_flat, p=1, dim=-1)  # 确保概率和为1
    entropy = -torch.sum(probs * torch.log2(probs + eps), dim=-1)
    return entropy


def get_extreme_entropy_indices(entropy_values, k=2):
    """
    获取每个样本中最大和最小熵值的块的索引，支持批量处理。
    输入形状：(B, num_patches_h, num_patches_w)
    返回形状：(B, k), (B, k)
    """
    batch_size, h_patches, w_patches = entropy_values.shape
    num_patches = h_patches * w_patches

    # 将熵值展平为一维向量并获取topk索引
    entropy_flat = entropy_values.reshape(batch_size, num_patches)
    max_indices = torch.topk(entropy_flat, k=k, largest=True).indices
    min_indices = torch.topk(entropy_flat, k=k, largest=False).indices

    return max_indices, min_indices


def entropy_patches(source_tensor, target_tensor, source_tensor_img, target_tensor_img,
                    patch_size=64, stride=64, k=2):
    """
    将源张量中熵值最小的k个块与目标张量中熵值最大的k个块进行交换，支持批量和多通道。
    优化点：减少循环，使用向量化操作，避免不必要的张量复制。
    """
    batch_size, _, height, width = target_tensor.shape

    # 分割张量 (B, h_patches, w_patches, C, patch_size, patch_size)
    source_patches = split_tensor_into_patches(source_tensor, patch_size, stride)
    target_patches = split_tensor_into_patches(target_tensor, patch_size, stride)
    source_img_patches = split_tensor_into_patches(source_tensor_img, patch_size, stride)
    target_img_patches = split_tensor_into_patches(target_tensor_img, patch_size, stride)

    # 计算熵 (B, h_patches, w_patches)
    source_entropy = calculate_entropy(source_patches)
    target_entropy = calculate_entropy(target_patches)

    # 获取极值索引 (B, k)
    max_indices_source, min_indices_source = get_extreme_entropy_indices(source_entropy, k)
    max_indices_target, min_indices_target = get_extreme_entropy_indices(target_entropy, k)

    # 展平patch张量以便于索引操作
    h_patches, w_patches = source_patches.shape[1:3]
    num_patches = h_patches * w_patches

    # 展平图像patch张量 (B, num_patches, C, patch_size, patch_size)
    source_img_flat = source_img_patches.reshape(batch_size, num_patches, -1, patch_size, patch_size)
    target_img_flat = target_img_patches.reshape(batch_size, num_patches, -1, patch_size, patch_size)

    # 创建索引矩阵以批量选择和替换patches
    batch_indices = torch.arange(batch_size).unsqueeze(1).expand(-1, k).to(source_tensor.device)

    # 执行交换操作
    # 注意：这里使用了临时变量来避免原地操作导致的数据覆盖问题
    source_min_patches = source_img_flat[batch_indices, min_indices_source]
    target_max_patches = target_img_flat[batch_indices, max_indices_target]

    # 创建输出副本并进行替换
    patched_source = source_img_flat.clone()
    patched_target = target_img_flat.clone()

    # 替换源图像中熵最小的区域为目标图像中熵最大的区域
    patched_source[batch_indices, min_indices_source] = target_max_patches
    # 替换目标图像中熵最大的区域为源图像中熵最小的区域
    patched_target[batch_indices, max_indices_target] = source_min_patches

    # 重建完整张量
    patched_source = patched_source.reshape(batch_size, h_patches, w_patches, -1, patch_size, patch_size)
    patched_target = patched_target.reshape(batch_size, h_patches, w_patches, -1, patch_size, patch_size)

    # 重新排列维度并合并patch
    patched_source = patched_source.permute(0, 3, 1, 4, 2, 5).reshape(batch_size, -1, height, width)
    patched_target = patched_target.permute(0, 3, 1, 4, 2, 5).reshape(batch_size, -1, height, width)

    return patched_source, patched_target
from scipy.optimize import linear_sum_assignment   # Hungarian

def entropy_patches_with_similarity(
        source_tensor, target_tensor,
        source_img_patches, target_img_patches,
        patch_size=64, stride=64, k=2):
    """
    先按熵选块，再在熵选块之间做相似度匹配后交换
    返回：交换后的完整张量
    """
    B, _, H, W = target_tensor.shape
    device = target_tensor.device

    # 1. 切 patch & 算熵
    src_prob = split_tensor_into_patches(source_tensor, patch_size, stride)
    tgt_prob = split_tensor_into_patches(target_tensor, patch_size, stride)
    src_img  = split_tensor_into_patches(source_img_patches, patch_size, stride)
    tgt_img  = split_tensor_into_patches(target_img_patches, patch_size, stride)

    src_ent = calculate_entropy(src_prob)   # (B, nH, nW)
    tgt_ent = calculate_entropy(tgt_prob)

    # 2. 熵极值索引
    min_idx_src = torch.topk(src_ent.view(B, -1), k=k, largest=False).indices  # (B, k)
    max_idx_tgt = torch.topk(tgt_ent.view(B, -1), k=k, largest=True ).indices  # (B, k)

    # 3. 展平 patch 方便索引
    nH, nW = src_prob.shape[1:3]
    npatch = nH * nW
    src_flat = src_img.reshape(B, npatch, -1, patch_size, patch_size)  # (B, npatch, C, ph, pw)
    tgt_flat = tgt_img.reshape(B, npatch, -1, patch_size, patch_size)

    # 4. 提取熵选块并展平为向量
    batch_idx = torch.arange(B).unsqueeze(1).expand(-1, k).to(device)
    src_blocks = src_flat[batch_idx, min_idx_src]   # (B, k, C*ph*pw)
    tgt_blocks = tgt_flat[batch_idx, max_idx_tgt]

    src_vec = src_blocks.reshape(B, k, -1).float()          # (B,k,D)
    tgt_vec = tgt_blocks.reshape(B, k, -1).float()

    # 5. 余弦相似度矩阵 (B, k, k)
    src_norm = F.normalize(src_vec, dim=-1)                 # 单位向量
    tgt_norm = F.normalize(tgt_vec, dim=-1)
    sim_mat = torch.bmm(src_norm, tgt_norm.transpose(1, 2)) # (B,k,k)

    # 6. 最大权二分匹配
    swap_pairs = []
    for b in range(B):
        row_ind, col_ind = linear_sum_assignment(sim_mat[b].cpu().numpy(), maximize=True)
        swap_pairs.append((torch.from_numpy(row_ind).to(device),
                           torch.from_numpy(col_ind).to(device)))

    # 7. 按匹配结果交换
    patched_src = src_flat.clone()
    patched_tgt = tgt_flat.clone()
    for b, (r, c) in enumerate(swap_pairs):
        patched_src[b, min_idx_src[b, r]] = tgt_flat[b, max_idx_tgt[b, c]]
        patched_tgt[b, max_idx_tgt[b, c]] = src_flat[b, min_idx_src[b, r]]

    # 8. 重建张量
    patched_src = patched_src.reshape(B, nH, nW, -1, patch_size, patch_size) \
                              .permute(0, 3, 1, 4, 2, 5) \
                              .reshape(B, -1, H, W)
    patched_tgt = patched_tgt.reshape(B, nH, nW, -1, patch_size, patch_size) \
                              .permute(0, 3, 1, 4, 2, 5) \
                              .reshape(B, -1, H, W)

    return patched_src, patched_tgt

# 使用示例
# if __name__ == "__main__":
#     import time
#
#     # 创建输入张量
#     B, C1, C2, H, W = 8, 2, 1, 256, 256
#     source_tensor = torch.rand(B, C1, H, W, device='cuda')
#     target_tensor = torch.rand(B, C1, H, W, device='cuda')
#     source_tensor_img = torch.rand(B, C2, H, W, device='cuda')
#     target_tensor_img = torch.rand(B, C2, H, W, device='cuda')
#
#     # 确保概率分布有效
#     source_tensor = F.normalize(source_tensor.reshape(B, C1, -1), p=1, dim=-1).reshape(B, C1, H, W)
#     target_tensor = F.normalize(target_tensor.reshape(B, C1, -1), p=1, dim=-1).reshape(B, C1, H, W)
#
#     # 预热运行
#     for _ in range(3):
#         _, _ = entropy_patches(source_tensor, target_tensor, source_tensor_img, target_tensor_img)
#
#     # 性能测试
#     torch.cuda.synchronize()
#     start_time = time.time()
#
#     for _ in range(10):
#         patched_source, patched_target = entropy_patches(
#             source_tensor, target_tensor, source_tensor_img, target_tensor_img,
#             patch_size=64, stride=64, k=2
#         )
#
#     torch.cuda.synchronize()
#     elapsed_time = time.time() - start_time
#     print(f"处理10次耗时: {elapsed_time:.4f}秒")
#     print(f"每次处理耗时: {elapsed_time / 10:.4f}秒")
#     print(f"输出形状: {patched_source.shape}, {patched_target.shape}")
