import torch
import torch.nn.functional as F
import numpy as np


class PixelwisePrototypeContrast:
    """
    像素级原型对比，针对分割任务优化
    """

    def __init__(self, num_classes, temperature=0.07, proto_weight=0.2,
                 sample_pixels=1000):
        """
        Args:
            sample_pixels: 每批采样的像素数，减少计算量
        """
        self.num_classes = num_classes
        self.temperature = temperature
        self.proto_weight = proto_weight
        self.sample_pixels = sample_pixels

        self.prototypes = {}
        self.update_counter = 0
        self.device = None

    def update_prototypes_quick(self, memory):
        """快速更新原型（不计算平均值，直接使用记忆中的特征）"""
        self.prototypes = {}

        for class_id in range(self.num_classes):
            if class_id < len(memory) and memory[class_id] is not None:
                class_features = memory[class_id]
                if len(class_features) > 0:
                    # 只取一个特征作为原型（最快）
                    if isinstance(class_features, np.ndarray):
                        prototype = torch.from_numpy(class_features[0]).float()
                    else:
                        prototype = torch.tensor(class_features[0], dtype=torch.float32)

                    # 简单标准化
                    norm = torch.norm(prototype)
                    if norm > 1e-6:
                        self.prototypes[class_id] = prototype / norm

    def compute_pixelwise_loss(self, features, pseudo_labels, memory):
        """像素级原型对比损失（采样减少计算量）"""
        if features.size(0) == 0:
            return torch.tensor(0.0, device=features.device)

        if self.device is None:
            self.device = features.device

        # 更新原型（如果需要）
        self.update_counter += 1
        if self.update_counter % 20 == 0:  # 每20批次更新一次
            self.update_prototypes_quick(memory)

        if not self.prototypes:
            return torch.tensor(0.0, device=self.device)

        # 采样像素减少计算量
        n_pixels = features.size(0)
        if n_pixels > self.sample_pixels:
            indices = torch.randperm(n_pixels)[:self.sample_pixels]
            features = features[indices]
            pseudo_labels = pseudo_labels[indices]

        # 准备原型
        class_ids = list(self.prototypes.keys())
        prototypes_list = [self.prototypes[cid].to(self.device) for cid in class_ids]
        if not prototypes_list:
            return torch.tensor(0.0, device=self.device)

        prototypes = torch.stack(prototypes_list)
        class_to_idx = {cid: idx for idx, cid in enumerate(class_ids)}

        # 快速过滤
        valid_mask = torch.tensor([label.item() in class_to_idx for label in pseudo_labels],
                                  device=self.device, dtype=torch.bool)

        if not valid_mask.any():
            return torch.tensor(0.0, device=self.device)

        # 归一化
        features_norm = F.normalize(features, dim=1)
        prototypes_norm = F.normalize(prototypes, dim=1)

        # 计算损失（只对有效像素）
        valid_features = features_norm[valid_mask]
        valid_labels = pseudo_labels[valid_mask]

        # 映射标签到原型索引
        proto_indices = torch.tensor([class_to_idx[label.item()] for label in valid_labels],
                                     device=self.device, dtype=torch.long)

        # 快速相似度计算
        sim_matrix = torch.einsum('nd,md->nm', valid_features, prototypes_norm) / self.temperature

        loss = F.cross_entropy(sim_matrix, proto_indices)

        return self.proto_weight * loss


class InconsistentRegionContrast:
    # 轻量级版本，最小化显存使
    """
    极简版本，最大程度减少显存使
    适合小显存GPU或大批量训练
    """

    def __init__(self, temperature=0.07, weight=1.0, max_samples=1024):
        self.temperature = temperature
        self.weight = weight
        self.max_samples = max_samples

    def compute_inconsistent_loss(self, feat1, feat2, mask_diff):
        """
        极简的对比损失计算
        最大程度减少中间变量
        """
        # 1. 直接计算不一致区域的索引，不生成完整mask
        B, C, H, W = feat1.shape
        total_pixels = B * H * W

        # 使用原地操作减少显存
        with torch.no_grad():
            # 展平mask，但使用视图而不是新张量
            if mask_diff.dim() > 1:
                mask_flat = mask_diff.view(-1)
            else:
                mask_flat = mask_diff

            # 获取不一致索引
            inconsistent_indices = mask_flat.nonzero(as_tuple=True)[0]
            n_inconsistent = len(inconsistent_indices)

            if n_inconsistent < 2:
                return torch.tensor(0.0, device=feat1.device)

            # 采样
            if n_inconsistent > self.max_samples:
                inconsistent_indices = inconsistent_indices[
                    torch.randperm(n_inconsistent, device=feat1.device)[:self.max_samples]
                ]
                n_inconsistent = self.max_samples

        # 2. 直接提取特征，避免创建中间变量
        # 将特征展平
        feat1_flat = feat1.permute(0, 2, 3, 1).reshape(-1, C)
        feat2_flat = feat2.permute(0, 2, 3, 1).reshape(-1, C)

        # 提取不一致特征
        feat1_inconsistent = feat1_flat[inconsistent_indices]  # [n, C]
        feat2_inconsistent = feat2_flat[inconsistent_indices]  # [n, C]

        # 3. 使用简单的对比损失，避免大矩阵
        loss = self._simple_contrastive_loss(feat1_inconsistent, feat2_inconsistent)

        # 清理中间变量（帮助GC）
        del feat1_flat, feat2_flat, inconsistent_indices

        return self.weight * loss

    def _simple_contrastive_loss(self, feat1, feat2):
        """简单的对比损失，避免相似度矩阵"""
        n = feat1.size(0)
        if n < 2:
            return torch.tensor(0.0, device=feat1.device)

        # 归一化
        feat1_norm = F.normalize(feat1, dim=1)
        feat2_norm = F.normalize(feat2, dim=1)

        # 使用简单的损失公式
        # 正样本相似度
        pos_sim = (feat1_norm * feat2_norm).sum(dim=1)  # [n]

        # 随机采样负样本（避免大矩阵）
        loss = 0.0
        for i in range(n):
            # 随机选择一个负样本
            j = torch.randint(0, n, (1,), device=feat1.device).item()
            while j == i and n > 1:
                j = torch.randint(0, n, (1,), device=feat1.device).item()

            neg_sim = torch.dot(feat1_norm[i], feat2_norm[j])

            # InfoNCE损失
            logits = torch.tensor([pos_sim[i], neg_sim], device=feat1.device) / self.temperature
            labels = torch.tensor([0], dtype=torch.long, device=feat1.device)
            loss += F.cross_entropy(logits.unsqueeze(0), labels)
        return loss / n


class InconsistentRegionContrast2:
    """
    加权版本2：直接对正样本相似度加权
    距离远的正样本相似度被放大，使模型更关注困难样本
    """

    def __init__(self, temperature=0.07, weight=1.0, max_samples=1024,
                 pos_weight_scale=2.0, normalize_weights=True):
        """
        参数:
            temperature: 对比学习温度系数
            weight: 损失总权重
            max_samples: 最大采样数
            pos_weight_scale: 正样本权重缩放因子
            normalize_weights: 是否归一化权重
        """
        self.temperature = temperature
        self.weight = weight
        self.max_samples = max_samples
        self.pos_weight_scale = pos_weight_scale
        self.normalize_weights = normalize_weights

    def compute_inconsistent_loss(self, feat1, feat2, mask_diff):
        """
        直接对正样本相似度加权
        """
        # 1. 获取不一致区域的索引
        B, C, H, W = feat1.shape

        with torch.no_grad():
            if mask_diff.dim() > 1:
                mask_flat = mask_diff.view(-1)
            else:
                mask_flat = mask_diff

            inconsistent_indices = mask_flat.nonzero(as_tuple=True)[0]
            n_inconsistent = len(inconsistent_indices)

            if n_inconsistent < 2:
                return torch.tensor(0.0, device=feat1.device)

            # 采样
            if n_inconsistent > self.max_samples:
                inconsistent_indices = inconsistent_indices[
                    torch.randperm(n_inconsistent, device=feat1.device)[:self.max_samples]
                ]
                n_inconsistent = self.max_samples

        # 2. 提取不一致区域的特征
        feat1_flat = feat1.permute(0, 2, 3, 1).reshape(-1, C)
        feat2_flat = feat2.permute(0, 2, 3, 1).reshape(-1, C)

        feat1_inconsistent = feat1_flat[inconsistent_indices]  # [n, C]
        feat2_inconsistent = feat2_flat[inconsistent_indices]  # [n, C]

        # 3. 计算加权对比损失
        loss = self._weighted_contrastive_loss_v2(feat1_inconsistent, feat2_inconsistent)

        # 清理中间变量
        del feat1_flat, feat2_flat, inconsistent_indices

        return self.weight * loss

    def _weighted_contrastive_loss_v2(self, feat1, feat2):
        """
        直接对正样本相似度加权的对比损失（版本2）

        核心思想：
        1. 计算正样本对的距离（1 - 相似度）
        2. 计算权重：exp(scale × distance) → 距离越远，权重越大
        3. 加权正样本相似度：weighted_sim = original_sim × weight
        4. 使用加权后的相似度计算InfoNCE损失
        """
        n = feat1.size(0)
        if n < 2:
            return torch.tensor(0.0, device=feat1.device)

        # 归一化特征
        feat1_norm = F.normalize(feat1, dim=1)  # [n, C]
        feat2_norm = F.normalize(feat2, dim=1)  # [n, C]

        total_loss = 0.0

        # 预计算所有样本对的相似度矩阵，用于负样本选择
        # 注意：这里使用小批量计算，避免O(n^2)内存
        with torch.no_grad():
            similarity_matrix = torch.matmul(feat1_norm, feat2_norm.T)  # [n, n]

        # 计算每个样本的正样本相似度和权重
        for i in range(n):
            # 获取原始正样本相似度
            original_pos_sim = similarity_matrix[i, i]  # 标量

            # 计算正样本距离
            pos_distance = 1.0 - original_pos_sim  # 距离：0表示相似，1表示不相似

            # 计算权重：距离越远，权重越大
            # 使用exp(scale × distance)形式
            pos_weight = torch.exp(self.pos_weight_scale * pos_distance)

            # 归一化权重（可选）
            if self.normalize_weights and i == 0:
                # 我们需要计算所有样本的权重来归一化
                all_pos_sims = torch.diag(similarity_matrix)
                all_pos_distances = 1.0 - all_pos_sims
                all_weights = torch.exp(self.pos_weight_scale * all_pos_distances)

                # 归一化，使平均权重为1
                mean_weight = all_weights.mean()
                if mean_weight > 1e-8:
                    normalized_weights = all_weights / mean_weight
                else:
                    normalized_weights = all_weights

            # 使用归一化权重或原始权重
            if self.normalize_weights:
                weight_i = normalized_weights[i]
            else:
                weight_i = pos_weight

            # 加权正样本相似度
            weighted_pos_sim = original_pos_sim * weight_i

            # 随机选择一个负样本（保持不变）
            j = torch.randint(0, n, (1,), device=feat1.device).item()
            while j == i and n > 1:
                j = torch.randint(0, n, (1,), device=feat1.device).item()

            # 获取负样本相似度
            neg_sim = similarity_matrix[i, j]

            # InfoNCE损失，使用加权后的正样本相似度
            logits = torch.stack([weighted_pos_sim, neg_sim]) / self.temperature
            labels = torch.tensor([0], dtype=torch.long, device=feat1.device)

            sample_loss = F.cross_entropy(logits.unsqueeze(0), labels)
            total_loss += sample_loss

        return total_loss / n

    # 更高效的批量计算版本（显存充足时使用）
    def _weighted_contrastive_loss_v2_batch(self, feat1, feat2):
        """
        批量计算加权对比损失
        更高效但需要更多显存
        """
        n = feat1.size(0)
        if n < 2:
            return torch.tensor(0.0, device=feat1.device)

        # 归一化特征
        feat1_norm = F.normalize(feat1, dim=1)  # [n, C]
        feat2_norm = F.normalize(feat2, dim=1)  # [n, C]

        # 计算相似度矩阵
        similarity_matrix = torch.matmul(feat1_norm, feat2_norm.T)  # [n, n]

        # 获取正样本相似度（对角线）
        original_pos_sims = torch.diag(similarity_matrix)  # [n]

        # 计算正样本距离
        pos_distances = 1.0 - original_pos_sims  # [n]

        # 计算权重：距离越远，权重越大
        pos_weights = torch.exp(self.pos_weight_scale * pos_distances)  # [n]

        # 归一化权重
        if self.normalize_weights:
            mean_weight = pos_weights.mean()
            if mean_weight > 1e-8:
                pos_weights = pos_weights / mean_weight

        # 加权正样本相似度
        weighted_pos_sims = original_pos_sims * pos_weights  # [n]

        # 创建负样本掩码（排除自身）
        neg_mask = ~torch.eye(n, dtype=torch.bool, device=feat1.device)  # [n, n]

        # 计算每个样本的InfoNCE损失
        losses = []
        for i in range(n):
            # 获取当前样本的正样本相似度（加权后的）
            pos_sim = weighted_pos_sims[i] / self.temperature

            # 获取负样本相似度
            neg_sims = similarity_matrix[i][neg_mask[i]] / self.temperature  # [n-1]

            # 合并正负样本对数概率
            logits = torch.cat([pos_sim.unsqueeze(0), neg_sims])

            # 计算交叉熵损失
            loss_i = F.cross_entropy(
                logits.unsqueeze(0),
                torch.tensor([0], dtype=torch.long, device=feat1.device)
            )
            losses.append(loss_i)

        losses = torch.stack(losses)  # [n]
        return losses.mean()

    # 保持原始不加权版本
    def compute_original_loss(self, feat1, feat2, mask_diff):
        """
        原始的对比损失，不加权
        """
        # 获取不一致区域的索引
        B, C, H, W = feat1.shape

        with torch.no_grad():
            if mask_diff.dim() > 1:
                mask_flat = mask_diff.view(-1)
            else:
                mask_flat = mask_diff

            inconsistent_indices = mask_flat.nonzero(as_tuple=True)[0]
            n_inconsistent = len(inconsistent_indices)

            if n_inconsistent < 2:
                return torch.tensor(0.0, device=feat1.device)

            if n_inconsistent > self.max_samples:
                inconsistent_indices = inconsistent_indices[
                    torch.randperm(n_inconsistent, device=feat1.device)[:self.max_samples]
                ]
                n_inconsistent = self.max_samples

        # 提取特征
        feat1_flat = feat1.permute(0, 2, 3, 1).reshape(-1, C)
        feat2_flat = feat2.permute(0, 2, 3, 1).reshape(-1, C)

        feat1_inconsistent = feat1_flat[inconsistent_indices]
        feat2_inconsistent = feat2_flat[inconsistent_indices]

        # 计算原始对比损失
        loss = self._original_contrastive_loss(feat1_inconsistent, feat2_inconsistent)

        return self.weight * loss

    def _original_contrastive_loss(self, feat1, feat2):
        """原始的对比损失，不加权"""
        n = feat1.size(0)
        if n < 2:
            return torch.tensor(0.0, device=feat1.device)

        # 归一化
        feat1_norm = F.normalize(feat1, dim=1)
        feat2_norm = F.normalize(feat2, dim=1)

        # 使用原来的简单损失公式
        loss = 0.0
        for i in range(n):
            # 正样本相似度
            pos_sim = torch.dot(feat1_norm[i], feat2_norm[i])

            # 随机选择一个负样本
            j = torch.randint(0, n, (1,), device=feat1.device).item()
            while j == i and n > 1:
                j = torch.randint(0, n, (1,), device=feat1.device).item()

            neg_sim = torch.dot(feat1_norm[i], feat2_norm[j])

            # InfoNCE损失
            logits = torch.tensor([pos_sim, neg_sim], device=feat1.device) / self.temperature
            labels = torch.tensor([0], dtype=torch.long, device=feat1.device)
            loss += F.cross_entropy(logits.unsqueeze(0), labels)

        return loss / n

