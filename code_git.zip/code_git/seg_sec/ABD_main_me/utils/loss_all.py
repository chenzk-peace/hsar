import torch
def PAL(model1, model2):
    v1, v2 = None, None
    for (p1, p2) in zip(model1.parameters(), model2.parameters()):
        if v1 is None and v2 is None:
            v1, v2 = p1.view(-1), p2.view(-1)
        else:
            v1, v2 = torch.cat((v1, p1.view(-1)), 0), torch.cat((v2, p2.view(-1)), 0)  # 拼接
    pac_loss = 1.0 + (torch.matmul(v1, v2) / (torch.norm(v1) * torch.norm(v2)))  # + 1  # +1 is for a positive loss
    return pac_loss