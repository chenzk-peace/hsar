import argparse
import logging
import os
import random
# import shutil
import sys
# import matplotlib.pyplot as plt
# import numpy as np
# import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from tensorboardX import SummaryWriter
# from torch.utils.data import DataLoader
from torchvision import transforms
from tqdm import tqdm
from skimage.measure import label
#
# from seg_sec.ABD_main_me.code.val_2D import test_single_volume_promise
# from seg_sec.ABD_main_me.code.utils.displacement import ABD_R_BCP
from seg_sec.ABD_main_me.code.dataloaders.datasetsec import (BaseDataSets, TwoStreamBatchSampler, WeakStrongAugment)
from seg_sec.ABD_main_me.code.networks.net_factory import BCP_net
from seg_sec.ABD_main_me.code.utils import ramps, losses
from seg_sec.ABD_main_me.code.val_2D import test_single_volume
# from MiDSS_master.code.dataloaders.dataloader_me import ThyroidSegmentation
from torch.utils.data import DataLoader, random_split
from seg_sec.ABD_main_me.utils.loss_all import PAL
from seg_sec.ABD_main_me.utils.zhifangtu import enhance_min_to_max
from seg_sec.ABD_main_me.utils.vatloss import VAT2d_v2_MT
from seg_sec.ABD_main_me.utils import feature_memory, contrastive_losses, cross_contra
# from seg_sec.ABD_main_me.utils.alterema import AlternatingEMAUpdateController
# from seg_sec.ABD_main_me.utils.augment import generate_unsup_data
# 在训练循环开始前添加存储结构

# from collections import deque
from seg_sec.ABD_main_me.utils.historybank import WeightedHistoricalMinImageBank

# import pywt
# from seg_sec.ABD_main_me.utils.patch_entropy import entropy_patches,get_extreme_entropy_indices,entropy_patches_with_similarity
a = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/ISIC'
b = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/Thyroid Dataset all'
c = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/BUSI'
d = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/DDTI'
e = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/TUD'
f = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/PKTN'
g = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/DDTI_GroupedSplit'
h = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/TUD_GroupedSplit'
i = '/media/pc/180A0B207684C9D9/czkdata/Czk_data/PKTN_GroupedSplit2'
# 7 增加了t和s低频的loss，以及bcp的复制粘贴位置不定
# 10 只增加了弱增强低频loss
parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str, default=g, help='Name of Experiment')
parser.add_argument('--exp', type=str, default='ces',
                    help='train_ACDC_Cross_Teaching/BCP')
parser.add_argument('--model', type=str, default='unet', help='model_name')
parser.add_argument('--pre_iterations', type=int, default=200, help='maximum epoch number to train')
parser.add_argument('--max_iterations', type=int, default=30000, help='maximum epoch number to train')
parser.add_argument('--batch_size', type=int, default=16, help='batch_size per gpu')
parser.add_argument('--deterministic', type=int, default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float, default=0.02, help='segmentation network learning rate')
parser.add_argument('--image_size', type=list, default=[256, 256], help='patch size of network input')
parser.add_argument('--seed', type=int, default=1337, help='random seed')
parser.add_argument('--num_classes', type=int, default=2, help='output channel of network')
# label and unlabel
parser.add_argument('--labeled_bs', type=int, default=8, help='labeled_batch_size per gpu')
parser.add_argument('--labelnum', type=float, default=0.05, help='labeled data')
parser.add_argument('--u_weight', type=float, default=0.5, help='weight of unlabeled pixels')
# costs
parser.add_argument('--gpu', type=str, default='0', help='GPU to use')
parser.add_argument('--consistency', type=float, default=1, help='consistency')
parser.add_argument('--consistency_rampup', type=float, default=150.0, help='consistency_rampup')
parser.add_argument('--magnitude', type=float, default='10.0', help='magnitude')
parser.add_argument('--s_param', type=int, default=6, help='multinum of random masks')
# patch size
parser.add_argument('--patch_size', type=int, default=64, help='patch_size')
parser.add_argument('--h_size', type=int, default=4, help='h_size')
parser.add_argument('--w_size', type=int, default=4, help='w_size')
# top num
parser.add_argument('--top_num', type=int, default=4, help='top_num')
parser.add_argument('--dataset', type=str, default='thy', choices=['fundus', 'prostate'])
parser.add_argument('--length', type=int, default='1024', choices=['fundus', 'prostate'])
args = parser.parse_args()
dice_loss = losses.DiceLoss(n_classes=2)
# dice_loss2 = losses.DiceLoss(n_classes=1)

import torch.fft

# from math import sqrt
import torch
import numpy as np
import pywt


def compute_pseudo_supervision_simple(out_soft_1, out_soft_1w, out_soft_2, out_soft_2w, w1w, w2w):
    """
    简化版本的伪监督损失计算
    """
    # 1. 计算权重
    w_sum = w1w + w2w + 1e-8
    weights_1 = w1w / w_sum
    weights_2 = w2w / w_sum

    # 2. 计算差异（作为不确定性度量）
    with torch.no_grad():
        # 计算强-弱输出差异
        diff_1 = F.mse_loss(out_soft_1, out_soft_1w, reduction='none')  # [B, H, W]
        diff_2 = F.mse_loss(out_soft_2, out_soft_2w, reduction='none')

        # 计算交叉差异
        cross_diff_1 = F.mse_loss(out_soft_1, out_soft_2w, reduction='none')
        cross_diff_2 = F.mse_loss(out_soft_2, out_soft_1w, reduction='none')

        # 融合差异（使用权重）
        # 模型1：使用自己的差异和交叉差异的加权平均
        uncertainty_1 = diff_1 * weights_1.unsqueeze(1) + cross_diff_1 * weights_2.unsqueeze(1)
        uncertainty_2 = diff_2 * weights_2.unsqueeze(1) + cross_diff_2 * weights_1.unsqueeze(1)  # 对称权重

        # 融合两个弱增强输出
        out_soft_fused = (out_soft_1w * weights_1.unsqueeze(1) +
                          out_soft_2w * weights_2.unsqueeze(1))
        out_pseudo_fused = torch.argmax(out_soft_fused, dim=1, keepdim=False)

    # 3. 计算加权的伪监督损失
    # 将伪标签转换为one-hot
    # num_classes = out_soft_1.shape[1]
    # pseudo_onehot = F.one_hot(out_pseudo_fused, num_classes).permute(0, 3, 1, 2).float()

    # 计算加权dice损失
    pseudo_supervision1 = dice_loss(out_soft_1, out_pseudo_fused.unsqueeze(1), uncertainty_1)
    pseudo_supervision2 = dice_loss(out_soft_2, out_pseudo_fused.unsqueeze(1), uncertainty_2)

    return pseudo_supervision1, pseudo_supervision2


def update_ema_variables_ave(model, model1, ema_model, alpha, global_step):
    # Use the true average until the exponential average is more correct
    alpha = min(1 - 1 / (global_step * 10 + 1), alpha)
    for ema_param, param, param1 in zip(ema_model.parameters(), model.parameters(), model1.parameters()):
        ema_param.data.mul_(alpha).add_(((param.data + param1.data) / 2) * (1 - alpha))


def update_ema_bn_variables_ave(model, model1, ema_model, alpha, global_step):
    # Use the true average until the exponential average is more correct
    alpha = min(1 - 1 / (global_step + 1), alpha)
    for ema_param, param, param1 in zip(ema_model.buffers(), model.buffers(), model1.buffers()):
        ema_param.data = ema_param.data * alpha + ((param.data + param1.data) / 2) * (1 - alpha)


def generate_top_k_threshold(con, proportion, choice):
    """
    使用topk方法生成阈值
    直接取前proportion比例的置信度的最小值作为阈值,

    Args:
        con: 置信度张量
        proportion: 比例，如0.2表示前20%
    Returns:
        threshold: 阈值
    """
    con_flat = con.view(-1)

    # 计算要取的样本数
    k = max(1, int(con_flat.numel() * proportion))
    if choice == 0:
        # 取最高的k个置信度
        topk_values, _ = torch.topk(con_flat, k)
        # 阈值 = 最高的k个中的最小值
        threshold = topk_values.min()
    else:
        topk_values, _ = torch.topk(con_flat, k, largest=False)
        # 阈值 = 最小的k个中的最大值
        threshold = topk_values.max()

    return threshold


def colorful_spectrum_mix_batch(img1_batch, img2_batch, alpha):
    """
    批量对图像进行频域混合。

    参数:
    img1_batch (torch.Tensor): 第一批图像，形状为 (N, C, H, W)
    img2_batch (torch.Tensor): 第二批图像，形状为 (N, C, H, W)
    alpha (float or torch.Tensor): 混合比例。如果是一个浮点数，则对所有图像使用相同的混合比例；如果是一个张量，则其形状应为 (N,)。

    返回:
    mixed_img1_batch (torch.Tensor): 第一批图像与第二批图像混合后的结果
    mixed_img2_batch (torch.Tensor): 第二批图像与第一批图像混合后的结果
    """
    assert img1_batch.shape == img2_batch.shape, "两批图像必须具有相同的尺寸和通道数"

    # 获取图像尺寸
    n, c, h, w = img1_batch.shape

    # 将 alpha 转换为张量

    # 计算中心区域的裁剪范围
    h_crop = int(0.2 * h)
    w_crop = int(0.2 * w)
    h_start = (h // 2) - (h_crop // 2)
    w_start = (w // 2) - (w_crop // 2)
    h_start2 = (h // 2) + (h_crop // 2)
    w_start2 = (w // 2) + (w_crop // 2)

    # 将图像从空间域转换到频域
    img1_fft = torch.fft.fftn(img1_batch, dim=(-2, -1))
    img2_fft = torch.fft.fftn(img2_batch, dim=(-2, -1))

    # 分离幅度和相位
    img1_abs = torch.abs(img1_fft)
    img1_pha = torch.angle(img1_fft)
    img2_abs = torch.abs(img2_fft)
    img2_pha = torch.angle(img2_fft)

    # 将FFT结果移到中心
    img1_abs = torch.fft.fftshift(img1_abs, dim=(-2, -1))
    img2_abs = torch.fft.fftshift(img2_abs, dim=(-2, -1))

    # 创建掩膜，标记中心区域
    mask = torch.zeros((h, w), dtype=torch.bool, device=img1_batch.device)
    mask[h_start:h_start2, w_start:w_start2] = 1

    # 扩展掩膜以匹配批次和通道维度
    mask_batch = mask.view(1, 1, h, w).expand(n, c, h, w)

    # 混合频域信息
    img1_abs_mixed = img1_abs.clone()
    img2_abs_mixed = img2_abs.clone()

    # 确保 alpha_batch 的形状与 img1_abs[mask_batch] 的形状匹配

    img1_abs_mixed[mask_batch] = alpha * img2_abs[mask_batch] + (1 - alpha) * img1_abs[mask_batch]
    img2_abs_mixed[mask_batch] = alpha * img1_abs[mask_batch] + (1 - alpha) * img2_abs[mask_batch]

    # 将FFT结果移回原位置
    img1_abs_mixed = torch.fft.ifftshift(img1_abs_mixed, dim=(-2, -1))
    img2_abs_mixed = torch.fft.ifftshift(img2_abs_mixed, dim=(-2, -1))

    # 将幅度信息与原始相位信息结合，生成新的频域信息
    img1_mixed = img1_abs_mixed * torch.exp(1j * img1_pha)
    img2_mixed = img2_abs_mixed * torch.exp(1j * img2_pha)

    # 逆傅里叶变换回空间域
    img1_mixed = torch.fft.ifftn(img1_mixed, dim=(-2, -1))
    img2_mixed = torch.fft.ifftn(img2_mixed, dim=(-2, -1))

    # 获取实部并裁剪到合法的像素值范围
    img1_mixed = torch.real(img1_mixed)
    img2_mixed = torch.real(img2_mixed)

    img1_mixed = torch.clamp(img1_mixed, 0, 255)
    img2_mixed = torch.clamp(img2_mixed, 0, 255)

    return img1_mixed, img2_mixed


def to_one_hot(tensor, nClasses):
    """ Input tensor : Nx1xHxW
    :param tensor:
    :param nClasses:
    :return:
    """
    assert tensor.max().item() < nClasses, 'one hot tensor.max() = {} < {}'.format(torch.max(tensor), nClasses)
    assert tensor.min().item() >= 0, 'one hot tensor.min() = {} < {}'.format(tensor.min(), 0)

    size = list(tensor.size())
    assert size[1] == 1
    size[1] = nClasses
    one_hot = torch.zeros(*size)
    if tensor.is_cuda:
        one_hot = one_hot.cuda(tensor.device)
    one_hot = one_hot.scatter_(1, tensor, 1)
    return one_hot


voxel_kl_loss = nn.KLDivLoss(reduction="none")


def softmax_mse_loss(input_logits, target_logits):
    """Takes softmax on both sides and returns MSE loss
    Note:
    - Returns the sum over all examples. Divide by the batch size afterwards
      if you want the mean.
    - Sends gradients to inputs but not the targets.
    """
    assert input_logits.size() == target_logits.size()
    input_softmax = F.softmax(input_logits, dim=1)
    # target_softmax = F.softmax(target_logits, dim=1)
    mse_loss = (input_softmax - target_logits) ** 2
    return mse_loss


def mix_mse_loss(net3_output, img_l, patch_l, mask, l_weight=1.0, u_weight=0.5, unlab=False, diff_mask=None):
    img_l, patch_l = img_l.type(torch.int64), patch_l.type(torch.int64)

    image_weight, patch_weight = l_weight, u_weight
    if unlab:
        image_weight, patch_weight = u_weight, l_weight

    patch_mask = 1 - mask
    img_l_onehot = to_one_hot(img_l.unsqueeze(1), 2)
    patch_l_onehot = to_one_hot(patch_l.unsqueeze(1), 2)

    mse_loss = torch.mean(softmax_mse_loss(net3_output, img_l_onehot), dim=1) * mask * image_weight
    mse_loss += torch.mean(softmax_mse_loss(net3_output, patch_l_onehot), dim=1) * patch_mask * patch_weight

    loss = torch.sum(diff_mask * mse_loss) / (torch.sum(diff_mask) + 1e-16)
    return loss


def load_net(net, path):
    state = torch.load(str(path))
    net.load_state_dict(state['net'])


def load_net_opt(net, optimizer, path):
    state = torch.load(str(path))
    net.load_state_dict(state['net'])
    optimizer.load_state_dict(state['opt'])


def save_net_opt(net, optimizer, path):
    state = {
        'net': net.state_dict(),
        'opt': optimizer.state_dict(),
    }
    torch.save(state, str(path))


def get_ACDC_LargestCC(segmentation):
    class_list = []
    for i in range(1, 4):
        temp_prob = segmentation == i * torch.ones_like(segmentation)
        temp_prob = temp_prob.detach().cpu().numpy()
        labels = label(temp_prob)
        # -- with 'try'
        assert (labels.max() != 0)  # assume at least 1 CC
        largestCC = labels == np.argmax(np.bincount(labels.flat)[1:]) + 1
        class_list.append(largestCC * i)
    acdc_largestCC = class_list[0] + class_list[1] + class_list[2]
    return torch.from_numpy(acdc_largestCC).cuda()


def get_ACDC_2DLargestCC(segmentation):
    batch_list = []
    N = segmentation.shape[0]
    for i in range(0, N):
        class_list = []
        for c in range(1, 4):
            temp_seg = segmentation[i]  # == c *  torch.ones_like(segmentation[i])
            # prob_seg = probcon[i]
            # a = temp_seg.cpu().numpy()
            # b = prob_seg.cpu().numpy()
            temp_prob = torch.zeros_like(temp_seg)
            # prob_prob = torch.zeros_like(temp_seg)
            temp_prob[temp_seg == c] = 1
            # prob_prob[prob_seg > 0.95] = 1

            # temp_prob = temp_prob

            temp_prob = temp_prob.detach().cpu().numpy()
            labels = label(temp_prob)
            if labels.max() != 0:
                largestCC = labels == np.argmax(np.bincount(labels.flat)[1:]) + 1
                class_list.append(largestCC * c)
            else:
                class_list.append(temp_prob)

        n_batch = class_list[0] + class_list[1] + class_list[2]
        batch_list.append(n_batch)

    return torch.Tensor(batch_list).cuda()


def get_ACDC_masks(output, nms=0):
    probs = F.softmax(output, dim=1)
    # _, probs = torch.max(probs, dim=1)
    _, probs = torch.max(probs, dim=1)
    if nms == 1:
        probs = get_ACDC_2DLargestCC(probs)
    return probs


def get_current_consistency_weight(epoch):
    # Consistency ramp-up from https://arxiv.org/abs/1610.02242
    return args.consistency * ramps.sigmoid_rampup(epoch, args.consistency_rampup)


def update_model_ema(model, ema_model, alpha):
    model_state = model.state_dict()
    model_ema_state = ema_model.state_dict()
    new_dict = {}
    for key in model_state:
        new_dict[key] = alpha * model_ema_state[key] + (1 - alpha) * model_state[key]
    ema_model.load_state_dict(new_dict)


def update_ema_variables(model, ema_model, alpha, global_step):
    # Use the true average until the exponential average is more correct
    alpha = min(1 - 1 / (global_step + 1), alpha)
    for ema_param, param in zip(ema_model.parameters(), model.parameters()):
        ema_param.data.mul_(alpha).add_(1 - alpha, param.data)


def update_ema_bn_variables(model, ema_model, alpha, global_step):
    # Use the true average until the exponential average is more correct
    alpha = min(1 - 1 / (global_step + 1), alpha)
    for ema_param, param in zip(ema_model.buffers(), model.buffers()):
        ema_param.data = ema_param.data * alpha + param.data * (1 - alpha)


def generate_mask(img):
    batch_size, channel, img_x, img_y = img.shape[0], img.shape[1], img.shape[2], img.shape[3]
    loss_mask = torch.ones(batch_size, img_x, img_y).cuda()
    mask = torch.ones(img_x, img_y).cuda()
    patch_x, patch_y = int(img_x * 2 / 3), int(img_y * 2 / 3)
    w = np.random.randint(0, img_x - patch_x)
    h = np.random.randint(0, img_y - patch_y)
    mask[w:w + patch_x, h:h + patch_y] = 0
    loss_mask[:, w:w + patch_x, h:h + patch_y] = 0
    return mask.long(), loss_mask.long()


def mix_loss(output, img_l, patch_l, mask, l_weight=1.0, u_weight=0.5, unlab=False):
    CE = nn.CrossEntropyLoss(reduction='none')
    img_l, patch_l = img_l.type(torch.int64), patch_l.type(torch.int64)
    output_soft = F.softmax(output, dim=1)
    image_weight, patch_weight = l_weight, u_weight
    if unlab:
        image_weight, patch_weight = u_weight, l_weight
    patch_mask = 1 - mask
    loss_dice = dice_loss(output_soft, img_l.unsqueeze(1), mask.unsqueeze(1)) * image_weight
    loss_dice += dice_loss(output_soft, patch_l.unsqueeze(1), patch_mask.unsqueeze(1)) * patch_weight
    loss_ce = image_weight * (CE(output, img_l) * mask).sum() / (mask.sum() + 1e-16)
    loss_ce += patch_weight * (CE(output, patch_l) * patch_mask).sum() / (patch_mask.sum() + 1e-16)  # loss = loss_ce
    return loss_dice, loss_ce


def mix_max_kl_loss(output, img_l, patch_l, mask, l_weight=1.0, u_weight=0.5, unlab=False):
    img_l, patch_l = img_l.type(torch.int64), patch_l.type(torch.int64)

    image_weight, patch_weight = l_weight, u_weight
    if unlab:
        image_weight, patch_weight = u_weight, l_weight

    patch_mask = 1 - mask

    with torch.no_grad():
        s1 = torch.softmax(output, dim=1)
        l1 = torch.argmax(s1, dim=1)
        img_diff_mask = (l1 != img_l)
        patch_diff_mask = (l1 != patch_l)

        uniform_distri = torch.ones(output.shape)
        uniform_distri = uniform_distri.cuda()

    kl_loss = torch.mean(voxel_kl_loss(F.log_softmax(output, dim=1), uniform_distri),
                         dim=1) * mask * img_diff_mask * image_weight
    kl_loss += torch.mean(voxel_kl_loss(F.log_softmax(output, dim=1), uniform_distri),
                          dim=1) * patch_mask * patch_diff_mask * patch_weight

    sum_diff = torch.sum(mask * img_diff_mask) + torch.sum(patch_mask * patch_diff_mask)
    loss = torch.sum(kl_loss) / (sum_diff + 1e-16)
    return loss


def patients_to_slices(dataset, patiens_num):
    ref_dict = None
    if "ACDC" in dataset:
        ref_dict = {"1": 32, "3": 68, "7": 136,
                    "14": 256, "21": 396, "28": 512, "35": 664, "70": 1312}
    elif "Prostate" in dataset:
        ref_dict = {"2": 27, "4": 53, "8": 120,
                    "12": 179, "16": 256, "21": 312, "42": 623}
    elif "Thyroid" in dataset:
        ref_dict = {"0.05": 143, "0.1": 287, "0.2": 575}
    else:
        print("Error")
    return ref_dict[str(patiens_num)]


def pre_train(args, snapshot_path):
    base_lr = args.base_lr
    num_classes = args.num_classes
    max_iterations = args.pre_iterations
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
    labeled_sub_bs, unlabeled_sub_bs = int(args.labeled_bs / 2), int((args.batch_size - args.labeled_bs) / 2)

    model = BCP_net(in_chns=1, class_num=num_classes)

    def worker_init_fn(worker_id):
        random.seed(args.seed + worker_id)

    db_train = BaseDataSets(base_dir=args.root_path,
                            split="train",
                            num=None,
                            transform=transforms.Compose([WeakStrongAugment(args.image_size)]))
    db_val = BaseDataSets(base_dir=args.root_path, split="val")

    labeled_train_set, unlabeled_train_set = random_split(db_train, [int(len(db_train) * args.labelnum),
                                                                     len(db_train) - int(
                                                                         len(db_train) * args.labelnum)],
                                                          generator=torch.Generator().manual_seed(0))
    labeled_idxs = labeled_train_set.indices
    unlabeled_idxs = unlabeled_train_set.indices

    print("Total slices is: {}, labeled slices is:{}".format(len(labeled_idxs + unlabeled_idxs), len(labeled_idxs)))

    batch_sampler = TwoStreamBatchSampler(labeled_idxs, unlabeled_idxs, args.batch_size,
                                          args.batch_size - args.labeled_bs)  # 不确定是否加上lbidx

    trainloader = DataLoader(db_train, batch_sampler=batch_sampler, num_workers=2, pin_memory=True,
                             worker_init_fn=worker_init_fn)

    valloader = DataLoader(db_val, batch_size=1, shuffle=False, num_workers=1)

    optimizer = optim.SGD(model.parameters(), lr=base_lr, momentum=0.9, weight_decay=0.0001)

    writer = SummaryWriter(snapshot_path + '/log')
    logging.info("Start pre_training")
    logging.info("{} iterations per epoch".format(len(trainloader)))

    model.train()

    iter_num = 0
    max_epoch = max_iterations // len(trainloader) + 1
    best_performance = 0.0
    best_hd = 100
    iterator = tqdm(range(max_epoch), ncols=70)
    for _ in iterator:
        for _, sampled_batch in enumerate(trainloader):
            volume_batch, label_batch = sampled_batch['image'], sampled_batch['label']
            volume_batch, label_batch = volume_batch.cuda(), label_batch.cuda()

            img_a, img_b = volume_batch[:labeled_sub_bs], volume_batch[labeled_sub_bs:args.labeled_bs]
            lab_a, lab_b = label_batch[:labeled_sub_bs], label_batch[labeled_sub_bs:args.labeled_bs]
            img_mask, loss_mask = generate_mask(img_a)

            gt_mixl = lab_a * img_mask + lab_b * (1 - img_mask)

            # -- original
            net_input = img_a * img_mask + img_b * (1 - img_mask)
            net_input2 = img_b * img_mask + img_a * (1 - img_mask)
            out_mixl, _ = model(net_input)
            out_mixl2, _ = model(net_input2)
            loss_dice, loss_ce = mix_loss(out_mixl, lab_a, lab_b, loss_mask, u_weight=1.0, unlab=True)
            loss_dice1, loss_ce1 = mix_loss(out_mixl2, lab_b, lab_a, loss_mask, u_weight=1.0, unlab=True)
            loss = (loss_dice + loss_ce + loss_dice1 + loss_ce1) / 2
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            lr_ = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr_

            iter_num += 1

            writer.add_scalar('info/total_loss', loss, iter_num)
            writer.add_scalar('info/mix_dice', loss_dice, iter_num)
            writer.add_scalar('info/mix_ce', loss_ce, iter_num)

            logging.info('iteration %d: loss: %f, mix_dice: %f, mix_ce: %f' % (iter_num, loss, loss_dice, loss_ce))
            if iter_num % 200 == 0:
                image = net_input[1, 0:1, :, :]
                writer.add_image('pre_train/Mixed_Image', image, iter_num)
                outputs = torch.argmax(torch.softmax(out_mixl, dim=1), dim=1, keepdim=True)
                writer.add_image('pre_train/Mixed_Prediction', outputs[1, ...] * 50, iter_num)
                labs = gt_mixl[1, ...].unsqueeze(0) * 50
                writer.add_image('pre_train/Mixed_GroundTruth', labs, iter_num)

            if iter_num > 0 and iter_num % 200 == 0:
                model.eval()
                metric_list = 0.0
                for _, sampled_batch in enumerate(valloader):
                    metric_i = test_single_volume(sampled_batch["image"].unsqueeze(1),
                                                  sampled_batch["label"].unsqueeze(1), model, classes=num_classes)  # 改
                    metric_list += np.array(metric_i)
                metric_list = metric_list / len(db_val)
                for class_i in range(num_classes - 1):
                    writer.add_scalar('info/val_{}_dice'.format(class_i + 1), metric_list[class_i, 0], iter_num)
                    writer.add_scalar('info/val_{}_hd95'.format(class_i + 1), metric_list[class_i, 1], iter_num)

                performance = np.mean(metric_list, axis=0)[0]
                writer.add_scalar('info/val_mean_dice', performance, iter_num)

                if performance > best_performance:
                    best_performance = performance
                    save_mode_path = os.path.join(snapshot_path,
                                                  'iter_{}_dice_{}.pth'.format(iter_num, round(best_performance, 4)))
                    save_best_path = os.path.join(snapshot_path, '{}_best_model.pth'.format(args.model))
                    save_net_opt(model, optimizer, save_mode_path)
                    save_net_opt(model, optimizer, save_best_path)

                logging.info('iteration %d : mean_dice : %f' % (iter_num, performance))
                model.train()

            if iter_num >= max_iterations:
                break
        if iter_num >= max_iterations:
            iterator.close()
            break
    writer.close()


def self_train(args, pre_snapshot_path, snapshot_path):
    base_lr = args.base_lr
    num_classes = args.num_classes
    max_iterations = args.max_iterations
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
    pre_trained_model = os.path.join(pre_snapshot_path, '{}_best_model.pth'.format(args.model))
    labeled_sub_bs, unlabeled_sub_bs = int(args.labeled_bs / 2), int((args.batch_size - args.labeled_bs) / 2)

    model_1 = BCP_net(in_chns=1, class_num=num_classes)
    model_2 = BCP_net(in_chns=1, class_num=num_classes)
    ema_model = BCP_net(in_chns=1, class_num=num_classes, ema=True)

    def worker_init_fn(worker_id):
        random.seed(args.seed + worker_id)

    db_train = BaseDataSets(base_dir=args.root_path,
                            split="train",
                            num=None,
                            transform=transforms.Compose([WeakStrongAugment(args.image_size)]))
    db_val = BaseDataSets(base_dir=args.root_path, split="val")

    labeled_train_set, unlabeled_train_set = random_split(db_train, [int(len(db_train) * args.labelnum),
                                                                     len(db_train) - int(
                                                                         len(db_train) * args.labelnum)],
                                                          generator=torch.Generator().manual_seed(0))
    labeled_idxs = labeled_train_set.indices
    unlabeled_idxs = unlabeled_train_set.indices

    batch_sampler = TwoStreamBatchSampler(labeled_idxs, unlabeled_idxs, args.batch_size,
                                          args.batch_size - args.labeled_bs)

    trainloader = DataLoader(db_train, batch_sampler=batch_sampler, num_workers=0, pin_memory=True,
                             worker_init_fn=worker_init_fn)

    valloader = DataLoader(db_val, batch_size=1, shuffle=False, num_workers=0)

    optimizer1 = optim.SGD(model_1.parameters(), lr=base_lr, momentum=0.9, weight_decay=0.0001)
    optimizer2 = optim.SGD(model_2.parameters(), lr=base_lr, momentum=0.9, weight_decay=0.0001)

    load_net(ema_model, pre_trained_model)

    load_net_opt(model_1, optimizer1, pre_trained_model)
    load_net_opt(model_2, optimizer2, pre_trained_model)
    logging.info("Loaded from {}".format(pre_trained_model))

    writer = SummaryWriter(snapshot_path + '/log')
    logging.info("Start self_training")
    logging.info("{} iterations per epoch".format(len(trainloader)))
    adv_loss = VAT2d_v2_MT(epi=args.magnitude)  ########## Mean Teacher

    model_1.train()
    model_2.train()
    ema_model.train()
    # proj_mlp1 = projection_MLP2(in_dim=16)
    prototype_memory = feature_memory.FeatureMemory(elements_per_class=32, n_classes=num_classes)
    inconsistent_contrast = cross_contra.InconsistentRegionContrast(
        temperature=0.1,
        weight=0.5

    )

    iter_num = 0
    max_epoch = max_iterations // len(trainloader) + 1
    best_performance1 = 0.0
    best_performance2 = 0.0
    iterator = tqdm(range(max_epoch), ncols=70)
    # 初始化历史图像存储系统
    historical_bank = WeightedHistoricalMinImageBank(
        max_size=10,  # 每个模型存储10个历史图像
        num_models=2,  # 两个模型
        selection_strategy='hybrid',  # 混合策略
        entropy_coeff=0.8, similarity_coeff=0.2

    )

    # 增强配置
    enhancement_config = {
        'method': 'hist_match_opencv',  # 增强方法
        'use_historical_prob': 1.0,  # 使用历史图像的概率
        'enable_bidirectional': True,  # 是否启用双向增强
        'min_history_for_use': 3,  # 开始使用历史图像的最小历史记录大小
    }
    for _ in iterator:
        for _, sampled_batch in enumerate(trainloader):
            volume_batch, label_batch = sampled_batch['image'], sampled_batch['label']
            volume_batch, label_batch = volume_batch.cuda(), label_batch.cuda()
            volume_batch_strong, label_batch_strong = sampled_batch['image_strong'], sampled_batch['label_strong']
            volume_batch_strong, label_batch_strong = volume_batch_strong.cuda(), label_batch_strong.cuda()
            volume_batch_strong_2, label_batch_strong_2 = sampled_batch['image_strong_2'].cuda(), sampled_batch[
                'label_strong_2'].cuda()
            img_a, img_b = volume_batch[:labeled_sub_bs], volume_batch[labeled_sub_bs:args.labeled_bs]
            uimg_a, uimg_b = volume_batch[args.labeled_bs:args.labeled_bs + unlabeled_sub_bs], volume_batch[
                args.labeled_bs + unlabeled_sub_bs:]
            lab_a, lab_b = label_batch[:labeled_sub_bs], label_batch[labeled_sub_bs:args.labeled_bs]

            img_a_s, img_b_s = volume_batch_strong[:labeled_sub_bs], volume_batch_strong[labeled_sub_bs:args.labeled_bs]
            uimg_a_s, uimg_b_s = volume_batch_strong[
                args.labeled_bs:args.labeled_bs + unlabeled_sub_bs], volume_batch_strong[
                args.labeled_bs + unlabeled_sub_bs:]
            lab_a_s, lab_b_s = label_batch_strong[:labeled_sub_bs], label_batch_strong[labeled_sub_bs:args.labeled_bs]

            img_a_s2, img_b_s2 = volume_batch_strong_2[:labeled_sub_bs], volume_batch_strong_2[
                labeled_sub_bs:args.labeled_bs]
            uimg_a_s2, uimg_b_s2 = volume_batch_strong_2[
                args.labeled_bs:args.labeled_bs + unlabeled_sub_bs], volume_batch_strong_2[
                args.labeled_bs + unlabeled_sub_bs:]
            lab_a_s2, lab_b_s2 = label_batch_strong_2[:labeled_sub_bs], label_batch_strong_2[
                labeled_sub_bs:args.labeled_bs]

            with torch.no_grad():
                pre_a, _ = ema_model(uimg_a)
                pre_b, _ = ema_model(uimg_b)

                plab_a = get_ACDC_masks(pre_a, nms=1)  # plab_a.shape=[6, 224, 224]
                plab_b = get_ACDC_masks(pre_b, nms=1)

                img_mask, loss_mask = generate_mask(img_a)
                unlab = plab_a * img_mask + lab_a * (1 - img_mask)
                lab = lab_b * img_mask + plab_b * (1 - img_mask)
                net_lab = torch.cat([unlab, lab], dim=0)
            consistency_weight = get_current_consistency_weight(iter_num // 150)

            net_input_unl_1w = uimg_a * img_mask + img_a * (1 - img_mask)
            net_input_l_1w = img_b * img_mask + uimg_b * (1 - img_mask)
            net_input_w = torch.cat([net_input_unl_1w, net_input_l_1w], dim=0)

            net_input_unl_1 = uimg_a_s * img_mask + img_a_s * (1 - img_mask)
            net_input_l_1 = img_b_s * img_mask + uimg_b_s * (1 - img_mask)
            net_input_1 = torch.cat([net_input_unl_1, net_input_l_1], dim=0)
            net_input_unl_2 = uimg_a_s2 * img_mask + img_a_s2 * (1 - img_mask)
            net_input_l_2 = img_b_s2 * img_mask + uimg_b_s2 * (1 - img_mask)
            net_input_2 = torch.cat([net_input_unl_2, net_input_l_2], dim=0)

            out_unl_1w, _ = model_1(net_input_unl_1w)
            out_l_1w, _ = model_1(net_input_l_1w)
            out_1w = torch.cat([out_unl_1w, out_l_1w], dim=0)
            out_soft_1w = torch.softmax(out_1w, dim=1)
            # out_max_1 = torch.max(out_soft_1.detach(), dim=1)[0]
            out_pseudo_1w = torch.argmax(out_soft_1w.detach(), dim=1, keepdim=False)
            unl_dice_1w, unl_ce_1w = mix_loss(out_unl_1w, plab_a, lab_a, loss_mask, u_weight=args.u_weight, unlab=True)
            l_dice_1w, l_ce_1w = mix_loss(out_l_1w, lab_b, plab_b, loss_mask, u_weight=args.u_weight)
            loss_ce_1w = unl_ce_1w + l_ce_1w
            loss_dice_1w = unl_dice_1w + l_dice_1w
            entropy_1w = -torch.sum(out_soft_1w.detach() * torch.log2(out_soft_1w.detach() + 1e-10), dim=1)

            w1w = torch.exp(-entropy_1w)
            w1_wmean = torch.mean(entropy_1w)
            w1_wmean_batch = torch.mean(entropy_1w, dim=(1, 2))
            min_idx_1 = torch.argmin(w1_wmean_batch)
            max_idx_1 = torch.argmax(w1_wmean_batch)

            out_unl_2w, _ = model_2(net_input_unl_1w)
            out_l_2w, _ = model_2(net_input_l_1w)
            out_2w = torch.cat([out_unl_2w, out_l_2w], dim=0)
            out_soft_2w = torch.softmax(out_2w, dim=1)
            # out_max_1 = torch.max(out_soft_1.detach(), dim=1)[0]
            out_pseudo_2w = torch.argmax(out_soft_2w.detach(), dim=1, keepdim=False)
            unl_dice_2w, unl_ce_2w = mix_loss(out_unl_2w, plab_a, lab_a, loss_mask, u_weight=args.u_weight, unlab=True)
            l_dice_2w, l_ce_2w = mix_loss(out_l_2w, lab_b, plab_b, loss_mask, u_weight=args.u_weight)
            loss_ce_2w = unl_ce_2w + l_ce_2w
            loss_dice_2w = unl_dice_2w + l_dice_2w
            entropy_2w = -torch.sum(out_soft_2w.detach() * torch.log2(out_soft_2w.detach() + 1e-10), dim=1)

            w2w = torch.exp(-entropy_2w)
            w2_wmean = torch.mean(entropy_2w)
            w2_wmean_batch = torch.mean(entropy_2w, dim=(1, 2))
            min_idx_2 = torch.argmin(w2_wmean_batch)
            max_idx_2 = torch.argmax(w2_wmean_batch)
            '''针对熵最大和最小的样本'''
            min_img1 = net_input_w[min_idx_1].unsqueeze(0)
            min_img2 = net_input_w[min_idx_2].unsqueeze(0)
            if max_idx_1 != max_idx_2:
                mean_var = (w1_wmean_batch - w2_wmean_batch) ** 2
                max_idx = torch.argmax(mean_var)
            else:
                max_idx = max_idx_1
            max_img1 = net_input_w[max_idx].unsqueeze(0)
            max_img2 = net_input_w[max_idx].unsqueeze(0)
            min_lab1 = net_lab[min_idx_1].unsqueeze(0)
            min_lab2 = net_lab[min_idx_2].unsqueeze(0)
            max_lab1 = net_lab[max_idx].unsqueeze(0)
            max_lab2 = net_lab[max_idx].unsqueeze(0)
            '''存储当前批次的最小熵图像'''
            # 获取熵值
            min_entropy1 = w1_wmean_batch[min_idx_1].item()
            min_entropy2 = w2_wmean_batch[min_idx_2].item()

            # 存储到历史记录
            historical_bank.add_min_images(
                model_idx=0,
                min_img=min_img1,
                entropy=min_entropy1,
                current_max_img=max_img1,
            )

            historical_bank.add_min_images(
                model_idx=1,
                min_img=min_img2,
                entropy=min_entropy2,
                current_max_img=max_img2,
            )

            '''选择增强源图像'''
            # 决定是否使用历史图像
            use_historical = (
                    enhancement_config['use_historical_prob'] > random.random() and
                    len(historical_bank.historical_min_images[0]) >= enhancement_config['min_history_for_use']
            )

            if use_historical:
                # 使用历史图像
                # 方法1：分别选择（可能选择不同的历史图像）
                historical_min_img1 = historical_bank.get_weighted_min_image(
                    model_idx=0,
                    current_max_img=max_img1,
                    default_img=min_img1
                )

                historical_min_img2 = historical_bank.get_weighted_min_image(
                    model_idx=1,
                    current_max_img=max_img2,
                    default_img=min_img2
                )

                min_img1 = historical_min_img1
                min_img2 = historical_min_img2

                # 记录使用了历史图像
                enhancement_source = "historical"
            else:
                # 使用当前批次的图像
                min_img1 = min_img1
                min_img2 = min_img2
                enhancement_source = "current"
            '''相同输入模型间一致性(可选原输入和增强后的输入，根据显存大小)'''
            mixlab = torch.cat([min_lab1, min_lab2, max_lab1, max_lab2], dim=0)
            mixall = torch.cat([min_img1, min_img2, max_img1, max_img2], dim=0)
            out_mix_1, feature_u = model_1(mixall)
            out_softmix_1 = torch.softmax(out_mix_1, dim=1)
            entropy_1mix = -torch.sum(out_softmix_1.detach() * torch.log2(out_softmix_1.detach() + 1e-10), dim=1)
            out_max_1 = torch.max(out_softmix_1, dim=1)[0]
            out_pseudomix_1 = torch.argmax(out_softmix_1.detach(), dim=1, keepdim=False)
            out_mix_2, feature_k = model_2(mixall)
            out_softmix_2 = torch.softmax(out_mix_2, dim=1)
            entropy_2mix = -torch.sum(out_softmix_2.detach() * torch.log2(out_softmix_2.detach() + 1e-10), dim=1)
            out_max_2 = torch.max(out_softmix_2, dim=1)[0]
            out_pseudomix_2 = torch.argmax(out_softmix_2.detach(), dim=1, keepdim=False)

            mix_loss_1 = dice_loss(out_softmix_1, out_pseudomix_2.unsqueeze(1))
            mix_loss_2 = dice_loss(out_softmix_2, out_pseudomix_1.unsqueeze(1))
            # 将模型1的min_img1直方图增强至max_img1
            min_img1_enhanced = enhance_min_to_max(
                min_img1,
                max_img1,
                method='hist_match_opencv'
            )
            max_img1_enhanced = enhance_min_to_max(
                max_img1,
                min_img1,
                method='hist_match_opencv'
            )
            min_img2_enhanced = enhance_min_to_max(
                min_img2,
                max_img2,
                method='hist_match_opencv'
            )
            max_img2_enhanced = enhance_min_to_max(
                max_img2,
                min_img2,
                method='hist_match_opencv'
            )
            with torch.no_grad():
                ema_enhance1_pre, _ = ema_model(torch.cat([min_img1, max_img1], dim=0))
                ema_enhance1_plab = get_ACDC_masks(ema_enhance1_pre, nms=1)
                ema_enhance2_pre, _ = ema_model(torch.cat([min_img2, max_img2], dim=0))
                ema_enhance2_plab = get_ACDC_masks(ema_enhance2_pre, nms=1)
            # for model_1
            enhan_model1_pre, _ = model_1(torch.cat([min_img1_enhanced, max_img1_enhanced], dim=0))
            enhan_model1_soft = torch.softmax(enhan_model1_pre, dim=1)
            enhan_loss_1 = dice_loss(enhan_model1_soft, ema_enhance1_plab.unsqueeze(1))
            # for model_2
            enhan_model2_pre, _ = model_2(torch.cat([min_img2_enhanced, max_img2_enhanced], dim=0))
            enhan_model2_soft = torch.softmax(enhan_model2_pre, dim=1)
            enhan_loss_2 = dice_loss(enhan_model2_soft, ema_enhance2_plab.unsqueeze(1))

            # The PDDCL features are extracted from mixall, whose order is:
            # [min_img1, min_img2, max_img1, max_img2].
            # Obtain the complementary enhanced pairs so M_self is defined for
            # all four feature groups, including historical images selected by
            # WeightedHistoricalMinImageBank.
            # These two auxiliary predictions are used only to construct M_self.
            # Run them in eval mode so BatchNorm running buffers are not updated
            # between the graph-building training forwards and loss.backward().
            _model1_was_training = model_1.training
            model_1.eval()
            with torch.no_grad():
                enhan_model1_other_pre, _ = model_1(
                    torch.cat([min_img2_enhanced, max_img2_enhanced], dim=0)
                )
                enhan_model1_other_soft = torch.softmax(enhan_model1_other_pre, dim=1)
            model_1.train(_model1_was_training)

            _model2_was_training = model_2.training
            model_2.eval()
            with torch.no_grad():
                enhan_model2_other_pre, _ = model_2(
                    torch.cat([min_img1_enhanced, max_img1_enhanced], dim=0)
                )
                enhan_model2_other_soft = torch.softmax(enhan_model2_other_pre, dim=1)
            model_2.train(_model2_was_training)

            # Reassemble the enhanced predictions in exactly the same order as mixall.
            enhan_model1_soft_all = torch.cat([
                enhan_model1_soft[0:1],
                enhan_model1_other_soft[0:1],
                enhan_model1_soft[1:2],
                enhan_model1_other_soft[1:2],
            ], dim=0).detach()
            enhan_model2_soft_all = torch.cat([
                enhan_model2_other_soft[0:1],
                enhan_model2_soft[0:1],
                enhan_model2_other_soft[1:2],
                enhan_model2_soft[1:2],
            ], dim=0).detach()

            # ================================================================
            # PDDCL pixel selection: implementation of Eqs. (1), (2), (7), (8), and (10).
            # Keep the original variable names used by the training code.
            # ================================================================
            with torch.no_grad():
                # Keep target labels aligned with mixall. When historical images
                # replace the current low-entropy samples, use the EMA predictions
                # already obtained for those actual historical images.
                mixlab_pddcl = mixlab.clone()
                if use_historical:
                    mixlab_pddcl[0] = ema_enhance1_plab[0]
                    mixlab_pddcl[1] = ema_enhance2_plab[0]

                # Eq. (2): M_cross^wk = M^t + M^s.
                # M^t: student disagreement with the corresponding teacher/GT target.
                # M^s: inter-student disagreement (element-wise XOR of predictions).
                M_cross_1 = (out_pseudomix_1 != mixlab_pddcl).float() + (
                        out_pseudomix_1 != out_pseudomix_2
                ).float()
                M_cross_2 = (out_pseudomix_2 != mixlab_pddcl).float() + (
                        out_pseudomix_1 != out_pseudomix_2
                ).float()

                # M_self^k: mean squared discrepancy between the same student's
                # original weak-view prediction and its histogram-enhanced view.
                M_self_1 = torch.mean(
                    (out_softmix_1.detach() - enhan_model1_soft_all) ** 2, dim=1
                )
                M_self_2 = torch.mean(
                    (out_softmix_2.detach() - enhan_model2_soft_all) ** 2, dim=1
                )

                # Eq. (1): entropy-weighted ensemble uncertainty maps.
                M_ensemble_1 = (
                        torch.exp(-entropy_1mix.detach()) * M_cross_1
                        + torch.exp(-entropy_2mix.detach()) * M_self_1
                )
                M_ensemble_2 = (
                        torch.exp(-entropy_1mix.detach()) * M_cross_2
                        + torch.exp(-entropy_2mix.detach()) * M_self_2
                )

                # Eq. (8): retain the original threshold variable names.
                # confidence_threshold is beta; entropy_threshold is gamma.
                # choice=1 selects the lower rho fraction for beta/gamma estimation.
                confidence_threshold = generate_top_k_threshold(
                    0.5 * (M_ensemble_1 + M_ensemble_2), 0.2, choice=1
                )
                entropy_threshold = generate_top_k_threshold(
                    0.5 * (entropy_1mix.detach() + entropy_2mix.detach()),
                    0.2,
                    choice=1,
                )

                # Eq. (7): reliable pixels for model 1 must satisfy all three conditions.
                mask_thre = M_ensemble_1 < confidence_threshold
                mask_entro = entropy_1mix < entropy_threshold
                mask_de = M_cross_1 == 0
                mask_all = mask_thre & mask_de & mask_entro

                # Eq. (7): the corresponding reliable-pixel set for model 2.
                mask_thre_2 = M_ensemble_2 < confidence_threshold
                mask_entro_2 = entropy_2mix < entropy_threshold
                mask_de_2 = M_cross_2 == 0
                mask_all_2 = mask_thre_2 & mask_de_2 & mask_entro_2

                # Eq. (10): unstable pixels for each student must also satisfy all three conditions.
                mask_diff1 = (
                        (M_ensemble_1 > confidence_threshold)
                        & (M_cross_1 > 0)
                        & (entropy_1mix > (1.0 - entropy_threshold))
                )
                mask_diff2 = (
                        (M_ensemble_2 > confidence_threshold)
                        & (M_cross_2 > 0)
                        & (entropy_2mix > (1.0 - entropy_threshold))
                )

            # Reliable pixels selected by Eq. (7) update the original prototype memory bank.
            '''model 1 contra'''
            labeled_features = feature_u.permute(0, 2, 3, 1)
            mask_prediction_correctly = (
                    (out_pseudomix_1 == mixlab_pddcl).float() * mask_all.float()
            ).bool()
            labels_correct = mixlab_pddcl[mask_prediction_correctly]
            labeled_features_correct = labeled_features[mask_prediction_correctly, ...]
            if labels_correct.numel() > 0:
                proj_labeled_features_correct = model_1.projection_head(
                    labeled_features_correct
                )
                with torch.no_grad():
                    prototype_memory.add_features_from_sample_learned(
                        model_1, proj_labeled_features_correct, labels_correct
                    )

            '''model 2 contra'''
            labeled_features_2 = feature_k.permute(0, 2, 3, 1)
            mask_prediction_correctly_2 = (
                    (out_pseudomix_2 == mixlab_pddcl).float() * mask_all_2.float()
            ).bool()
            labels_correct_2 = mixlab_pddcl[mask_prediction_correctly_2]
            labeled_features_correct_2 = labeled_features_2[mask_prediction_correctly_2, ...]
            if labels_correct_2.numel() > 0:
                proj_labeled_features_correct_2 = model_2.projection_head(
                    labeled_features_correct_2
                )
                with torch.no_grad():
                    prototype_memory.add_features_from_sample_learned(
                        model_2, proj_labeled_features_correct_2, labels_correct_2
                    )

            a = iter_num / max_iterations
            min_img1_mp, max_img1_mp = colorful_spectrum_mix_batch(min_img1, max_img1,
                                                                   alpha=a)
            min_img2_mp, max_img2_mp = colorful_spectrum_mix_batch(min_img2, max_img2,
                                                                   alpha=a)
            # for model_1
            mp_model1_pre, _ = model_1(torch.cat([min_img1_mp, max_img1_mp], dim=0))
            mp_model1_soft = torch.softmax(mp_model1_pre, dim=1)
            mp_loss_1 = dice_loss(mp_model1_soft, ema_enhance1_plab.unsqueeze(1))
            # for model_2
            mp_model2_pre, _ = model_2(torch.cat([min_img2_mp, max_img2_mp], dim=0))
            mp_model2_soft = torch.softmax(mp_model2_pre, dim=1)
            mp_loss_2 = dice_loss(mp_model2_soft, ema_enhance2_plab.unsqueeze(1))

            '''创建不确定性图'''
            diffmask_unlab_s1t = (out_pseudo_1w[:labeled_sub_bs] != unlab).float()
            diffmask_unlab_s2t = (out_pseudo_2w[:labeled_sub_bs] != unlab).float()
            diffmask_lab_s1t = (out_pseudo_1w[labeled_sub_bs:] != lab).float()
            diffmask_lab_s2t = (out_pseudo_2w[labeled_sub_bs:] != lab).float()
            diffmask_unlab_s1s2 = (out_pseudo_1w[:labeled_sub_bs] != out_pseudo_2w[:labeled_sub_bs]).float()
            diffmask_lab_s1s2 = (out_pseudo_1w[labeled_sub_bs:] != out_pseudo_2w[labeled_sub_bs:]).float()

            diffmask_unlab_1 = (diffmask_unlab_s1t + diffmask_unlab_s1s2) / 2
            diffmask_unlab_2 = (diffmask_unlab_s2t + diffmask_unlab_s1s2) / 2
            diffmask_lab_1 = (diffmask_lab_s1t + diffmask_lab_s1s2) / 2
            diffmask_lab_2 = (diffmask_lab_s2t + diffmask_lab_s1s2) / 2

            net1_mse_loss_unlab = mix_mse_loss(out_unl_1w, plab_a.long(), lab_a, loss_mask, unlab=True,
                                               diff_mask=diffmask_unlab_1)
            net1_mse_loss_lab = mix_mse_loss(out_l_1w, lab_b, plab_b.long(), loss_mask, diff_mask=diffmask_lab_1)
            net2_mse_loss_unlab = mix_mse_loss(out_unl_2w, plab_a.long(), lab_a, loss_mask, unlab=True,
                                               diff_mask=diffmask_unlab_2)
            net2_mse_loss_lab = mix_mse_loss(out_l_2w, lab_b, plab_b.long(), loss_mask, diff_mask=diffmask_lab_2)

            # strong aug
            out_unl_1, _ = model_1(net_input_unl_1)
            out_l_1, _ = model_1(net_input_l_1)
            out_1 = torch.cat([out_unl_1, out_l_1], dim=0)
            out_soft_1 = torch.softmax(out_1, dim=1)
            # out_max_1, out_indice_1 = torch.max(out_soft_1.detach(), dim=1)
            # out_pseudo_1 = torch.argmax(out_soft_1.detach(), dim=1, keepdim=False)
            unl_dice_1, unl_ce_1 = mix_loss(out_unl_1, plab_a, lab_a_s, loss_mask, u_weight=args.u_weight,
                                            unlab=True)
            l_dice_1, l_ce_1 = mix_loss(out_l_1, lab_b_s, plab_b, loss_mask, u_weight=args.u_weight)
            loss_ce_1 = unl_ce_1 + l_ce_1
            loss_dice_1 = unl_dice_1 + l_dice_1
            entropy_1 = -torch.sum(out_soft_1.detach() * torch.log2(out_soft_1.detach() + 1e-10), dim=1)
            # w1仅用于计算权重
            # w1 = torch.exp(-entropy_1)

            # w1_mean仅用于比较
            w1_mean = torch.mean(entropy_1)

            out_unl_2, _ = model_2(net_input_unl_2)
            out_l_2, _ = model_2(net_input_l_2)
            out_2 = torch.cat([out_unl_2, out_l_2], dim=0)
            out_soft_2 = torch.softmax(out_2, dim=1)
            # out_max_2, out_indice_2 = torch.max(out_soft_2.detach(), dim=1)
            # out_pseudo_2 = torch.argmax(out_soft_2.detach(), dim=1, keepdim=False)
            unl_dice_2, unl_ce_2 = mix_loss(out_unl_2, plab_a, lab_a_s2, loss_mask, u_weight=args.u_weight,
                                            unlab=True)
            l_dice_2, l_ce_2 = mix_loss(out_l_2, lab_b_s2, plab_b, loss_mask, u_weight=args.u_weight)
            loss_ce_2 = unl_ce_2 + l_ce_2
            loss_dice_2 = unl_dice_2 + l_dice_2
            entropy_2 = -torch.sum(out_soft_2.detach() * torch.log2(out_soft_2.detach() + 1e-10), dim=1)

            # w2 = torch.exp(-entropy_2)

            w2_mean = torch.mean(entropy_2)
            pseudo_supervision1w, pseudo_supervision2w = compute_pseudo_supervision_simple(
                out_soft_1, out_soft_1w, out_soft_2, out_soft_2w, w1w, w2w
            )

            pseudo_supervisioninter1 = (out_soft_1 - out_soft_1w) ** 2
            pseudo_supervisioninter2 = (out_soft_2 - out_soft_2w) ** 2
            pseudo_supervisionouter1 = (out_soft_1 - out_soft_2w) ** 2
            pseudo_supervisionouter2 = (out_soft_2 - out_soft_1w) ** 2

            # Model1 Loss
            # Model1 & Model2 Cross Pseudo Supervision
            pseudo_supervision1 = dice_loss(out_soft_1, out_pseudo_1w.unsqueeze(1), pseudo_supervisioninter1)
            pseudo_supervision2 = dice_loss(out_soft_2, out_pseudo_2w.unsqueeze(1), pseudo_supervisioninter2)
            # parameter adversarial loss
            pal_loss = PAL(model_1, model_2)
            loss_lds1 = adv_loss(model_1, ema_model, mixall[2:])
            loss_lds2 = adv_loss(model_2, ema_model, mixall[2:])

            unlabeled_features1 = feature_u.permute(0, 2, 3, 1)
            unlabeled_features_1 = unlabeled_features1.reshape(-1, unlabeled_features1.size()[-1])
            pseudo_label1 = out_pseudomix_1.reshape(-1)
            unlabeled_features2 = feature_k.permute(0, 2, 3, 1)
            unlabeled_features_2 = unlabeled_features2.reshape(-1, unlabeled_features2.size()[-1])
            pseudo_label2 = out_pseudomix_2.reshape(-1)

            # get predicted features
            proj_feat_unlabeled_1 = model_1.projection_head(unlabeled_features_1)
            pred_feat_unlabeled_1 = model_1.prediction_head(proj_feat_unlabeled_1)
            proj_feat_unlabeled_2 = model_2.projection_head(unlabeled_features_2)
            pred_feat_unlabeled_2 = model_2.prediction_head(proj_feat_unlabeled_2)

            # Apply contrastive learning loss
            contrastive_loss1 = contrastive_losses.contrastive_class_to_class_learned_memory(model_1,
                                                                                             pred_feat_unlabeled_1,
                                                                                             pseudo_label1,
                                                                                             num_classes,
                                                                                             prototype_memory.memory)
            contrastive_loss2 = contrastive_losses.contrastive_class_to_class_learned_memory(model_2,
                                                                                             pred_feat_unlabeled_2,
                                                                                             pseudo_label2,
                                                                                             num_classes,
                                                                                             prototype_memory.memory)

            # 2. 不一致区域对比学习
            inconsistent_loss1 = inconsistent_contrast.compute_inconsistent_loss(
                feature_u, feature_k, mask_diff1
            )
            inconsistent_loss2 = inconsistent_contrast.compute_inconsistent_loss(
                feature_u, feature_k, mask_diff2
            )

            loss_1 = (((loss_dice_1 + loss_ce_1) / 2 + pseudo_supervision1)
                      + 0.1 * pal_loss + (
                              loss_dice_1w + loss_ce_1w) / 2 + pseudo_supervision1w
                      + 0.5 * net1_mse_loss_unlab + 0.5 * net1_mse_loss_lab + mix_loss_1 + enhan_loss_1 + 0.2 * loss_lds1 + mp_loss_1
                      + 0.1 * contrastive_loss1 + 0.1 * inconsistent_loss1)
            loss_2 = (((loss_dice_2 + loss_ce_2) / 2 + pseudo_supervision2)
                      + 0.1 * pal_loss + (
                              loss_dice_2w + loss_ce_2w) / 2 + pseudo_supervision2w
                      + 0.5 * net2_mse_loss_unlab + 0.5 * net2_mse_loss_lab + mix_loss_2 + enhan_loss_2 + 0.2 * loss_lds2 + mp_loss_2
                      + 0.1 * contrastive_loss2 + 0.1 * inconsistent_loss2)

            loss = loss_1 + loss_2

            optimizer1.zero_grad()
            optimizer2.zero_grad()

            loss.backward()  # 计算总梯度

            optimizer1.step()
            optimizer2.step()

            update_ema_variables_ave(model_1, model_2, ema_model, 0.99, iter_num)
            lr_ = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
            for param_group in optimizer1.param_groups:
                param_group['lr'] = lr_
            for param_group in optimizer2.param_groups:
                param_group['lr'] = lr_

            '''定期显示统计信息'''
            if iter_num % 200 == 0:
                stats = historical_bank.get_stats()
                iterator.set_postfix({
                    'iter': iter_num,
                    'history_size': stats['model_stats'][0]['history_size'],
                    'avg_entropy': f"{stats['model_stats'][0]['avg_entropy']:.3f}",
                    'source': enhancement_source,
                    'consistency_loss': f"{loss.item():.4f}"
                })
            iter_num += 1

            writer.add_scalar('info/total_loss', loss, iter_num)
            writer.add_scalar('info/model1_loss', loss_1, iter_num)
            writer.add_scalar('info/model2_loss', loss_2, iter_num)
            writer.add_scalar('info/pal_loss', pal_loss, iter_num)

            writer.add_scalar('info/consistency_weight', consistency_weight, iter_num)

            logging.info(
                'iteration %d\t: loss: %4f\t, model1_loss: %4f\t, model2_loss: %4f\t, pal_loss: %4f\t, incons1_loss: %4f\t, incons2_loss: %4f\t' % (
                    iter_num, loss,
                    loss_1, loss_2,
                    pal_loss, inconsistent_loss1, inconsistent_loss2))
            logging.info(
                'mse_un1: %4f\t, mse_1: %4f\t, mse_un2: %4f\t, mse_2: %4f\t, mp1: %4f\t, mp2: %4f\t' % (
                    net1_mse_loss_unlab,
                    net1_mse_loss_lab, net2_mse_loss_unlab,
                    net2_mse_loss_lab, mp_loss_1, mp_loss_2))
            logging.info(
                'mixl1: %4f\t, mixl2: %4f\t, enhan1: %4f\t, enhan2: %4f\t, lds1: %4f\t,lds2: %4f\t,contra1: %4f\t,contra2: %4f\t' % (
                    mix_loss_1,
                    mix_loss_2, enhan_loss_1,
                    enhan_loss_2, loss_lds1, loss_lds2, contrastive_loss1, contrastive_loss2))

            if iter_num > 0 and iter_num % 200 == 0:
                model_1.eval()
                metric_list = 0.0
                for _, sampled_batch in enumerate(valloader):
                    metric_i = test_single_volume(sampled_batch["image"].unsqueeze(1),
                                                  sampled_batch["label"].unsqueeze(1), model_1, classes=num_classes)
                    metric_list += np.array(metric_i)
                metric_list = metric_list / len(db_val)
                for class_i in range(num_classes - 1):
                    writer.add_scalar('info/model1_val_{}_dice'.format(class_i + 1), metric_list[class_i, 0], iter_num)
                    writer.add_scalar('info/model1_val_{}_hd95'.format(class_i + 1), metric_list[class_i, 1], iter_num)
                performance1 = np.mean(metric_list, axis=0)[0]
                writer.add_scalar('info/model1_val_mean_dice', performance1, iter_num)

                if performance1 > best_performance1 or performance1 >= 0.87:
                    best_performance1 = performance1
                    save_mode_path = os.path.join(snapshot_path, 'model1_iter_{}_dice_{}.pth'.format(iter_num, round(
                        best_performance1, 4)))
                    save_best_path = os.path.join(snapshot_path, '{}_best_model1.pth'.format(args.model))
                    torch.save(model_1.state_dict(), save_mode_path)
                    torch.save(model_1.state_dict(), save_best_path)

                logging.info('iteration %d : model1_mean_dice : %f' % (iter_num, performance1))
                model_1.train()

                model_2.eval()
                metric_list = 0.0
                for _, sampled_batch in enumerate(valloader):
                    metric_i = test_single_volume(sampled_batch["image"].unsqueeze(1),
                                                  sampled_batch["label"].unsqueeze(1), model_2, classes=num_classes)
                    metric_list += np.array(metric_i)
                metric_list = metric_list / len(db_val)
                for class_i in range(num_classes - 1):
                    writer.add_scalar('info/model2_val_{}_dice'.format(class_i + 1), metric_list[class_i, 0], iter_num)
                    writer.add_scalar('info/model2_val_{}_hd95'.format(class_i + 1), metric_list[class_i, 1], iter_num)
                performance2 = np.mean(metric_list, axis=0)[0]
                writer.add_scalar('info/model2_val_mean_dice', performance2, iter_num)

                if performance2 > best_performance2 or performance2 >= 0.87:
                    best_performance2 = performance2
                    save_mode_path = os.path.join(snapshot_path, 'model2_iter_{}_dice_{}.pth'.format(iter_num, round(
                        best_performance2, 4)))
                    save_best_path = os.path.join(snapshot_path, '{}_best_model2.pth'.format(args.model))
                    torch.save(model_2.state_dict(), save_mode_path)
                    torch.save(model_2.state_dict(), save_best_path)

                logging.info('iteration %d : model2_mean_dice : %f' % (iter_num, performance2))
                model_2.train()

            if iter_num >= max_iterations:
                break
        if iter_num >= max_iterations:
            iterator.close()
            break
        writer.close()


if __name__ == "__main__":
    if args.deterministic:
        cudnn.benchmark = False
        cudnn.deterministic = True
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed(args.seed)

    # -- path to save models
    pre_snapshot_path = "/home/pc/Czk/seg_sec/ABD_main_me/model/para/thy_{}_{}_labeled/pre_train".format(
        args.exp,
        args.labelnum)
    self_snapshot_path = "/home/pc/Czk/seg_sec/ABD_main_me/model/para/thy_{}_{}_labeled/self_train".format(
        args.exp,
        args.labelnum)
    for snapshot_path in [pre_snapshot_path, self_snapshot_path]:
        if not os.path.exists(snapshot_path):
            os.makedirs(snapshot_path)
    # shutil.copy('/home/pc/Czk/seg_sec/ABD_main/code/train_ACDC_BCP.py', self_snapshot_path)

    # Pre_train
    logging.basicConfig(filename=pre_snapshot_path + "/log.txt", level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))
    pre_train(args, pre_snapshot_path)

    # Self_train
    logging.basicConfig(filename=self_snapshot_path + "/log.txt", level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))
    self_train(args, pre_snapshot_path, self_snapshot_path)





